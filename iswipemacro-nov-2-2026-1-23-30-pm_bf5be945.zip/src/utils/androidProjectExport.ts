/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';

export interface AndroidProjectFile {
  path: string;
  content: string;
  description: string;
  language: 'kotlin' | 'xml' | 'gradle' | 'properties' | 'markdown' | 'toml';
}

export function getAndroidProjectFiles(): AndroidProjectFile[] {
  return [
    {
      path: 'README.md',
      language: 'markdown',
      description: 'Quick Start & Build Instructions for Android Studio & Redmi Note 11T 5G',
      content: `# iSwipeMacro - Android Gaming Gesture Studio

A standalone, non-root Android application for recording, visualizing, analyzing, and replaying swipe and touch gestures inside an interactive high-performance practice arena.

Designed with a modern gaming HUD aesthetic in dark purple and electric neon cyan, optimized for modern Android smartphones including the **Redmi Note 11T 5G (FHD+ 1080x2400 @ 90Hz)**.

---

## 🚀 How to Build & Run in Android Studio

### Prerequisites
1. **Android Studio**: Android Studio Koala, Ladybug, or Iguana (2024.1+ recommended).
2. **JDK**: OpenJDK 17 or JDK 21 (bundled with modern Android Studio).
3. **Android Device or Emulator**: Android 7.0 (API 24) to Android 15 (API 35). Tested on Redmi Note 11T 5G.

### Step 1: Open the Project
1. Extract the downloaded \`iSwipeMacro_Android_Project.zip\` to a folder on your computer.
2. Launch Android Studio.
3. Click **Open** (or **File > Open**) and select the unzipped \`iSwipeMacro\` root folder.
4. Allow Gradle Sync to finish downloading required dependencies.

### Step 2: Connect Your Redmi Note 11T 5G (or other Android device)
1. On your phone, go to **Settings > About Phone**.
2. Tap **MIUI Version / OS Version** 7 times until you see *"You are now a developer!"*.
3. Go back to **Settings > Additional Settings > Developer Options**.
4. Enable **USB Debugging** and **Install via USB**.
5. Connect your phone via USB cable and tap **Allow USB Debugging** on the phone screen.

### Step 3: Build & Install Debug APK
- **From Android Studio UI**:
  Select your connected device from the device dropdown at the top toolbar, then click the green **Run (▶)** button or press \`Shift + F10\`.
- **From Terminal / Command Line**:
  \`\`\`bash
  # Linux / macOS
  ./gradlew assembleDebug

  # Windows PowerShell / CMD
  .\\gradlew.bat assembleDebug
  \`\`\`

The compiled debug APK will be created at:
\`app/build/outputs/apk/debug/app-debug.apk\`

To install directly to your connected phone via adb:
\`\`\`bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
\`\`\`

---

## ⚡ Main App Features

1. **Practice Arena Gesture Recording**:
   - High-rate touch sampling (up to 90Hz/120Hz matching Redmi Note 11T 5G touch sampling).
   - Records normalized coordinates (\`nx\`, \`ny\`) so gestures scale across any screen aspect ratio.
   - Preserves exact relative delta timing and pressure.
2. **Visual Replay Engine**:
   - Replays gestures smoothly inside the practice arena with original order and timing.
   - Dynamic ghost touch pointer with glowing neon trail and ripple effects.
   - Variable playback speeds: 0.25x, 0.5x, 1.0x, 1.5x, 2.0x, 3.0x, 5.0x.
   - Configurable repeat loops and interval delays.
3. **Subtle Tactile Haptic Feedback**:
   - Subtle double pulse on gesture record start.
   - Single crisp tick on record stop.
   - Rising pulse on replay start.
   - Double tick on replay stop.
   - Enhances tactile feedback without overwhelming the user.
4. **Local Profile Management**:
   - Saves gestures locally with full telemetry (total travel distance, peak speed, point count).
   - Inline rename, profile deletion, profile duplication.
   - Preloaded gaming macro presets (FPS Snap, MOBA Skillshot, Zig-Zag Evasion).
5. **Security & Privacy Policy**:
   - Non-root compliant: operates strictly within the application's practice surface.
   - Does NOT inject touches into foreign applications or bypass Android security sandbox.
`
    },
    {
      path: 'settings.gradle.kts',
      language: 'gradle',
      description: 'Project settings and dependency repository configuration',
      content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "iSwipeMacro"
include(":app")
`
    },
    {
      path: 'build.gradle.kts',
      language: 'gradle',
      description: 'Root build Gradle configuration',
      content: `plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
`
    },
    {
      path: 'gradle/libs.versions.toml',
      language: 'toml',
      description: 'Modern Android Gradle Version Catalog',
      content: `[versions]
agp = "8.7.2"
kotlin = "2.0.21"
coreKtx = "1.15.0"
lifecycleRuntimeKtx = "2.8.7"
activityCompose = "1.9.3"
composeBom = "2024.11.00"
coroutines = "1.9.0"
gson = "2.11.0"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version.ref = "lifecycleRuntimeKtx" }
androidx-lifecycle-viewmodel-compose = { group = "androidx.lifecycle", name = "lifecycle-viewmodel-compose", version.ref = "lifecycleRuntimeKtx" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version.ref = "activityCompose" }
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-ui-graphics = { group = "androidx.compose.ui", name = "ui-graphics" }
androidx-ui-tooling = { group = "androidx.compose.ui", name = "ui-tooling" }
androidx-ui-tooling-preview = { group = "androidx.compose.ui", name = "ui-tooling-preview" }
androidx-material3 = { group = "androidx.compose.material3", name = "material3" }
androidx-material-icons-extended = { group = "androidx.compose.material", name = "material-icons-extended" }
kotlinx-coroutines-android = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-android", version.ref = "coroutines" }
google-gson = { group = "com.google.code.gson", name = "gson", version.ref = "gson" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
`
    },
    {
      path: 'gradle/wrapper/gradle-wrapper.properties',
      language: 'properties',
      description: 'Gradle wrapper version properties',
      content: `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.9-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
    },
    {
      path: 'app/build.gradle.kts',
      language: 'gradle',
      description: 'App module build script with Jetpack Compose & Haptics support',
      content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.iswipemacro.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.iswipemacro.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.google.gson)

    debugImplementation(libs.androidx.ui.tooling)
}
`
    },
    {
      path: 'app/src/main/AndroidManifest.xml',
      language: 'xml',
      description: 'Android Manifest declaring Vibrate permission and main activity',
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Subtle Haptic Feedback Permission -->
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:hardwareAccelerated="true"
        android:theme="@style/Theme.ISwipeMacro">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
            android:screenOrientation="portrait"
            android:theme="@style/Theme.ISwipeMacro">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`
    },
    {
      path: 'app/src/main/java/com/iswipemacro/app/model/GestureModels.kt',
      language: 'kotlin',
      description: 'Data models for touch points, strokes, and gesture profiles',
      content: `package com.iswipemacro.app.model

import java.util.UUID

enum class PointType {
    DOWN, MOVE, UP
}

data class TouchPoint(
    val x: Float,
    val y: Float,
    val nx: Float, // Normalized X (0.0f - 1.0f)
    val ny: Float, // Normalized Y (0.0f - 1.0f)
    val timestamp: Long, // Relative milliseconds from gesture start
    val type: PointType = PointType.MOVE,
    val pressure: Float = 1.0f,
    val velocity: Float = 0f
)

data class GestureStroke(
    val id: String = UUID.randomUUID().toString(),
    val points: List<TouchPoint> = emptyList(),
    val startTime: Long = 0L,
    val endTime: Long = 0L,
    val lengthPx: Float = 0f
)

data class GestureProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val durationMs: Long,
    val strokes: List<GestureStroke>,
    val totalPoints: Int,
    val totalDistancePx: Float,
    val averageVelocityPxPerSec: Float,
    val category: String = "General",
    val colorHex: String = "#00F0FF"
)

enum class PlaybackState {
    IDLE, RECORDING, PLAYING, PAUSED
}
`
    },
    {
      path: 'app/src/main/java/com/iswipemacro/app/util/HapticsManager.kt',
      language: 'kotlin',
      description: 'Vibration & tactile feedback controller for subtle haptic notifications',
      content: `package com.iswipemacro.app.util

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Manages subtle haptic feedback for iSwipeMacro.
 * Provides distinct, non-overwhelming tactile cues for:
 * 1. Recording Start (gentle double pulse)
 * 2. Recording Stop (single crisp tick)
 * 3. Replay Start (rising buzz)
 * 4. Replay Stop (double short tick)
 */
class HapticsManager(context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    var isEnabled: Boolean = true

    /**
     * Subtle vibration when user STARTS recording a gesture.
     */
    fun onRecordStart() {
        if (!isEnabled || vibrator == null || !vibrator.hasVibrator()) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Gentle double pulse: [wait 0ms, vibrate 25ms, sleep 35ms, vibrate 25ms]
            val timings = longArrayOf(0, 25, 35, 25)
            val amplitudes = intArrayOf(0, 160, 0, 180)
            val effect = VibrationEffect.createWaveform(timings, amplitudes, -1)
            vibrator.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(longArrayOf(0, 25, 35, 25), -1)
        }
    }

    /**
     * Subtle vibration when user STOPS recording a gesture.
     */
    fun onRecordStop() {
        if (!isEnabled || vibrator == null || !vibrator.hasVibrator()) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Standard crisp effect
            vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(38, 200))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(38)
        }
    }

    /**
     * Subtle vibration when gesture REPLAY begins.
     */
    fun onReplayStart() {
        if (!isEnabled || vibrator == null || !vibrator.hasVibrator()) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Rising smooth double buzz
            val timings = longArrayOf(0, 20, 25, 30)
            val amplitudes = intArrayOf(0, 120, 0, 210)
            val effect = VibrationEffect.createWaveform(timings, amplitudes, -1)
            vibrator.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(longArrayOf(0, 20, 25, 30), -1)
        }
    }

    /**
     * Subtle vibration when gesture REPLAY is stopped.
     */
    fun onReplayStop() {
        if (!isEnabled || vibrator == null || !vibrator.hasVibrator()) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Crisp double tick
            val timings = longArrayOf(0, 20, 20, 20)
            val amplitudes = intArrayOf(0, 180, 0, 180)
            val effect = VibrationEffect.createWaveform(timings, amplitudes, -1)
            vibrator.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(longArrayOf(0, 20, 20, 20), -1)
        }
    }

    fun onButtonTap() {
        if (!isEnabled || vibrator == null || !vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(15, 120))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(15)
        }
    }
}
`
    },
    {
      path: 'app/src/main/java/com/iswipemacro/app/viewmodel/GestureViewModel.kt',
      language: 'kotlin',
      description: 'State ViewModel managing recording, replay timing, and local storage',
      content: `package com.iswipemacro.app.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.iswipemacro.app.model.*
import com.iswipemacro.app.util.HapticsManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.hypot

class GestureViewModel(application: Application) : AndroidViewModel(application) {

    private val haptics = HapticsManager(application)
    private val prefs = application.getSharedPreferences("iswipemacro_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    // Playback state
    private val _playbackState = MutableStateFlow(PlaybackState.IDLE)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    // Current active gesture in practice canvas
    private val _activeStrokes = MutableStateFlow<List<GestureStroke>>(emptyList())
    val activeStrokes: StateFlow<List<GestureStroke>> = _activeStrokes.asStateFlow()

    // Replay cursor position for ghost touch indicator
    private val _ghostPointer = MutableStateFlow<TouchPoint?>(null)
    val ghostPointer: StateFlow<TouchPoint?> = _ghostPointer.asStateFlow()

    // Saved profiles list
    private val _savedProfiles = MutableStateFlow<List<GestureProfile>>(emptyList())
    val savedProfiles: StateFlow<List<GestureProfile>> = _savedProfiles.asStateFlow()

    // Currently selected profile
    private val _selectedProfile = MutableStateFlow<GestureProfile?>(null)
    val selectedProfile: StateFlow<GestureProfile?> = _selectedProfile.asStateFlow()

    // Replay settings
    var replaySpeed = MutableStateFlow(1.0f)
    var repeatCount = MutableStateFlow(1)
    var repeatDelayMs = MutableStateFlow(300L)
    var hapticsEnabled = MutableStateFlow(true)

    // Telemetry
    private val _telemetryText = MutableStateFlow("X: 000 | Y: 000 | Ready")
    val telemetryText: StateFlow<String> = _telemetryText.asStateFlow()

    // Internal recording state
    private var recordingStartTime = 0L
    private var currentRecordingStrokePoints = mutableListOf<TouchPoint>()
    private var replayJob: Job? = null

    init {
        loadSavedProfiles()
    }

    fun startRecording() {
        if (_playbackState.value == PlaybackState.RECORDING) return
        stopReplay()

        _activeStrokes.value = emptyList()
        _ghostPointer.value = null
        currentRecordingStrokePoints.clear()
        recordingStartTime = System.currentTimeMillis()
        _playbackState.value = PlaybackState.RECORDING

        // Haptic feedback for recording start
        if (hapticsEnabled.value) {
            haptics.onRecordStart()
        }
        _telemetryText.value = "RECORDING ENGAGED... Draw inside practice area"
    }

    fun onTouchDown(x: Float, y: Float, nx: Float, ny: Float, pressure: Float = 1.0f) {
        if (_playbackState.value != PlaybackState.RECORDING) return
        val relTime = System.currentTimeMillis() - recordingStartTime
        val point = TouchPoint(x, y, nx, ny, relTime, PointType.DOWN, pressure)
        currentRecordingStrokePoints = mutableListOf(point)
        _telemetryText.value = "DOWN: (\${x.toInt()}, \${y.toInt()}) [T: \${relTime}ms]"
    }

    fun onTouchMove(x: Float, y: Float, nx: Float, ny: Float, pressure: Float = 1.0f) {
        if (_playbackState.value != PlaybackState.RECORDING) return
        val relTime = System.currentTimeMillis() - recordingStartTime
        val point = TouchPoint(x, y, nx, ny, relTime, PointType.MOVE, pressure)
        currentRecordingStrokePoints.add(point)

        // Live preview of active drawing
        val currentList = _activeStrokes.value.toMutableList()
        val tempStroke = GestureStroke(
            points = currentRecordingStrokePoints.toList(),
            startTime = currentRecordingStrokePoints.firstOrNull()?.timestamp ?: 0L,
            endTime = relTime
        )
        if (currentList.isNotEmpty() && currentList.last().id == "active-stroke") {
            currentList[currentList.size - 1] = tempStroke.copy(id = "active-stroke")
        } else {
            currentList.add(tempStroke.copy(id = "active-stroke"))
        }
        _activeStrokes.value = currentList
        _telemetryText.value = "MOVE: (\${x.toInt()}, \${y.toInt()}) [Pts: \${currentRecordingStrokePoints.size}]"
    }

    fun onTouchUp(x: Float, y: Float, nx: Float, ny: Float) {
        if (_playbackState.value != PlaybackState.RECORDING) return
        val relTime = System.currentTimeMillis() - recordingStartTime
        val point = TouchPoint(x, y, nx, ny, relTime, PointType.UP)
        currentRecordingStrokePoints.add(point)

        // Compute stroke distance
        var dist = 0f
        for (i in 0 until currentRecordingStrokePoints.size - 1) {
            val p1 = currentRecordingStrokePoints[i]
            val p2 = currentRecordingStrokePoints[i + 1]
            dist += hypot(p2.x - p1.x, p2.y - p1.y)
        }

        val completedStroke = GestureStroke(
            points = currentRecordingStrokePoints.toList(),
            startTime = currentRecordingStrokePoints.firstOrNull()?.timestamp ?: 0L,
            endTime = relTime,
            lengthPx = dist
        )

        val updated = _activeStrokes.value.filter { it.id != "active-stroke" }.toMutableList()
        updated.add(completedStroke)
        _activeStrokes.value = updated
        currentRecordingStrokePoints.clear()
        _telemetryText.value = "STROKE FINISHED: \${dist.toInt()}px"
    }

    fun stopRecording() {
        if (_playbackState.value != PlaybackState.RECORDING) return
        _playbackState.value = PlaybackState.IDLE

        // Haptic feedback for recording stop
        if (hapticsEnabled.value) {
            haptics.onRecordStop()
        }

        val strokes = _activeStrokes.value
        val totalPts = strokes.sumOf { it.points.size }
        val totalDist = strokes.sumOf { it.lengthPx.toDouble() }.toFloat()
        val duration = if (strokes.isNotEmpty()) strokes.maxOf { it.endTime } else 0L

        _telemetryText.value = "RECORDING STOPPED | Pts: $totalPts | Dur: \${duration}ms"
    }

    fun startReplay(canvasWidth: Float, canvasHeight: Float) {
        val strokes = _activeStrokes.value
        if (strokes.isEmpty()) {
            _telemetryText.value = "No gesture recorded yet to replay!"
            return
        }

        stopReplay()
        _playbackState.value = PlaybackState.PLAYING

        // Haptic feedback for replay start
        if (hapticsEnabled.value) {
            haptics.onReplayStart()
        }

        replayJob = viewModelScope.launch {
            val allPoints = strokes.flatMap { it.points }.sortedBy { it.timestamp }
            if (allPoints.isEmpty()) {
                _playbackState.value = PlaybackState.IDLE
                return@launch
            }

            val loops = if (repeatCount.value <= 0) 9999 else repeatCount.value
            val speed = replaySpeed.value.coerceIn(0.25f, 5.0f)

            for (currentLoop in 1..loops) {
                if (_playbackState.value != PlaybackState.PLAYING) break

                val baseTime = System.currentTimeMillis()
                for (pt in allPoints) {
                    if (_playbackState.value != PlaybackState.PLAYING) break

                    val scaledTargetTime = (pt.timestamp / speed).toLong()
                    val elapsed = System.currentTimeMillis() - baseTime
                    val waitMs = (scaledTargetTime - elapsed).coerceAtLeast(0L)
                    if (waitMs > 0) {
                        delay(waitMs)
                    }

                    // Denormalize points to current canvas size
                    val denormX = pt.nx * canvasWidth
                    val denormY = pt.ny * canvasHeight
                    _ghostPointer.value = pt.copy(x = denormX, y = denormY)
                    _telemetryText.value = "REPLAY: (\${denormX.toInt()}, \${denormY.toInt()}) Loop: $currentLoop"
                }

                if (currentLoop < loops && _playbackState.value == PlaybackState.PLAYING) {
                    delay(repeatDelayMs.value)
                }
            }

            stopReplay()
        }
    }

    fun stopReplay() {
        if (replayJob?.isActive == true || _playbackState.value == PlaybackState.PLAYING) {
            replayJob?.cancel()
            replayJob = null
            _ghostPointer.value = null
            _playbackState.value = PlaybackState.IDLE

            // Haptic feedback for replay stop
            if (hapticsEnabled.value) {
                haptics.onReplayStop()
            }
            _telemetryText.value = "REPLAY FINISHED"
        }
    }

    fun saveCurrentGesture(name: String, category: String = "General"): Boolean {
        val strokes = _activeStrokes.value
        if (strokes.isEmpty()) return false

        val totalPts = strokes.sumOf { it.points.size }
        val totalDist = strokes.sumOf { it.lengthPx.toDouble() }.toFloat()
        val duration = strokes.maxOfOrNull { it.endTime } ?: 0L
        val avgSpeed = if (duration > 0) (totalDist / (duration / 1000f)) else 0f

        val profile = GestureProfile(
            name = name.ifBlank { "Gesture #\${_savedProfiles.value.size + 1}" },
            durationMs = duration,
            strokes = strokes,
            totalPoints = totalPts,
            totalDistancePx = totalDist,
            averageVelocityPxPerSec = avgSpeed,
            category = category
        )

        val updated = _savedProfiles.value.toMutableList()
        updated.add(0, profile)
        _savedProfiles.value = updated
        _selectedProfile.value = profile
        persistProfiles(updated)
        return true
    }

    fun loadProfile(profile: GestureProfile) {
        stopReplay()
        _selectedProfile.value = profile
        _activeStrokes.value = profile.strokes
        _telemetryText.value = "Loaded: \${profile.name} (\${profile.totalPoints} pts)"
    }

    fun deleteProfile(profileId: String) {
        val updated = _savedProfiles.value.filter { it.id != profileId }
        _savedProfiles.value = updated
        if (_selectedProfile.value?.id == profileId) {
            _selectedProfile.value = null
        }
        persistProfiles(updated)
    }

    fun renameProfile(profileId: String, newName: String) {
        val updated = _savedProfiles.value.map {
            if (it.id == profileId) it.copy(name = newName, updatedAt = System.currentTimeMillis()) else it
        }
        _savedProfiles.value = updated
        persistProfiles(updated)
    }

    fun clearAllProfiles() {
        _savedProfiles.value = emptyList()
        _selectedProfile.value = null
        persistProfiles(emptyList())
    }

    fun clearCanvas() {
        stopReplay()
        _activeStrokes.value = emptyList()
        _ghostPointer.value = null
        _telemetryText.value = "Practice canvas cleared"
    }

    private fun persistProfiles(profiles: List<GestureProfile>) {
        val json = gson.toJson(profiles)
        prefs.edit().putString("saved_profiles_json", json).apply()
    }

    private fun loadSavedProfiles() {
        val json = prefs.getString("saved_profiles_json", null)
        if (!json.isNullOrBlank()) {
            try {
                val type = object : TypeToken<List<GestureProfile>>() {}.type
                val list: List<GestureProfile> = gson.fromJson(json, type)
                _savedProfiles.value = list
            } catch (e: Exception) {
                _savedProfiles.value = emptyList()
            }
        }
    }
}
`
    },
    {
      path: 'app/src/main/java/com/iswipemacro/app/ui/PracticeCanvas.kt',
      language: 'kotlin',
      description: 'Interactive Jetpack Compose Practice Area with glowing neon path and ghost replayer',
      content: `package com.iswipemacro.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import com.iswipemacro.app.model.GestureStroke
import com.iswipemacro.app.model.TouchPoint
import com.iswipemacro.app.ui.theme.CyberCyan
import com.iswipemacro.app.ui.theme.DeepObsidian
import com.iswipemacro.app.ui.theme.ElectricViolet

@Composable
fun PracticeCanvas(
    modifier: Modifier = Modifier,
    activeStrokes: List<GestureStroke>,
    ghostPointer: TouchPoint?,
    isRecording: Boolean,
    onTouchDown: (x: Float, y: Float, nx: Float, ny: Float) -> Unit,
    onTouchMove: (x: Float, y: Float, nx: Float, ny: Float) -> Unit,
    onTouchUp: (x: Float, y: Float, nx: Float, ny: Float) -> Unit,
    onSizeChanged: (width: Float, height: Float) -> Unit
) {
    var canvasSize by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepObsidian)
            .pointerInput(isRecording) {
                detectDragGestures(
                    onDragStart = { offset ->
                        if (size.width > 0 && size.height > 0) {
                            onTouchDown(
                                offset.x,
                                offset.y,
                                (offset.x / size.width).coerceIn(0f, 1f),
                                (offset.y / size.height).coerceIn(0f, 1f)
                            )
                        }
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        if (size.width > 0 && size.height > 0) {
                            onTouchMove(
                                change.position.x,
                                change.position.y,
                                (change.position.x / size.width).coerceIn(0f, 1f),
                                (change.position.y / size.height).coerceIn(0f, 1f)
                            )
                        }
                    },
                    onDragEnd = {
                        // Drag end
                    },
                    onDragCancel = {
                        // Drag cancel
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (canvasSize != Offset(size.width, size.height)) {
                canvasSize = Offset(size.width, size.height)
                onSizeChanged(size.width, size.height)
            }

            // Draw subtle high-tech cyber grid
            val gridSpacing = 40f
            var x = 0f
            while (x < size.width) {
                drawLine(
                    color = CyberCyan.copy(alpha = 0.06f),
                    start = Offset(x, 0f),
                    end = Offset(x, size.height),
                    strokeWidth = 1f
                )
                x += gridSpacing
            }
            var y = 0f
            while (y < size.height) {
                drawLine(
                    color = CyberCyan.copy(alpha = 0.06f),
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1f
                )
                y += gridSpacing
            }

            // Draw recorded strokes with glowing neon gradient
            for (stroke in activeStrokes) {
                if (stroke.points.size < 2) continue
                val path = Path()
                val first = stroke.points.first()
                val startX = first.nx * size.width
                val startY = first.ny * size.height
                path.moveTo(startX, startY)

                for (i in 1 until stroke.points.size) {
                    val pt = stroke.points[i]
                    val px = pt.nx * size.width
                    val py = pt.ny * size.height
                    path.lineTo(px, py)
                }

                // Outer ambient glow
                drawPath(
                    path = path,
                    color = ElectricViolet.copy(alpha = 0.35f),
                    style = Stroke(width = 16f)
                )
                // Mid glow
                drawPath(
                    path = path,
                    color = CyberCyan.copy(alpha = 0.65f),
                    style = Stroke(width = 8f)
                )
                // Crisp core
                drawPath(
                    path = path,
                    color = Color.White,
                    style = Stroke(width = 3f)
                )

                // Start waypoint marker
                drawCircle(
                    color = CyberCyan,
                    radius = 8f,
                    center = Offset(startX, startY)
                )
            }

            // Draw ghost touch replay reticle
            ghostPointer?.let { ghost ->
                val gx = ghost.nx * size.width
                val gy = ghost.ny * size.height

                // Pulsing target ring
                drawCircle(
                    color = CyberCyan.copy(alpha = 0.25f),
                    radius = 32f,
                    center = Offset(gx, gy)
                )
                drawCircle(
                    color = CyberCyan,
                    radius = 18f,
                    center = Offset(gx, gy),
                    style = Stroke(width = 3f)
                )
                drawCircle(
                    color = Color.White,
                    radius = 6f,
                    center = Offset(gx, gy)
                )

                // Crosshair reticle lines
                drawLine(
                    color = CyberCyan,
                    start = Offset(gx - 26f, gy),
                    end = Offset(gx + 26f, gy),
                    strokeWidth = 2f
                )
                drawLine(
                    color = CyberCyan,
                    start = Offset(gx, gy - 26f),
                    end = Offset(gx, gy + 26f),
                    strokeWidth = 2f
                )
            }
        }
    }
}
`
    },
    {
      path: 'app/src/main/java/com/iswipemacro/app/ui/HomeScreen.kt',
      language: 'kotlin',
      description: 'Main Gaming UI Dashboard with Record, Stop, Replay controls and Telemetry',
      content: `package com.iswipemacro.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iswipemacro.app.model.PlaybackState
import com.iswipemacro.app.ui.theme.*
import com.iswipemacro.app.viewmodel.GestureViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: GestureViewModel,
    onOpenSavedGestures: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenInfo: () -> Unit
) {
    val playbackState by viewModel.playbackState.collectAsState()
    val activeStrokes by viewModel.activeStrokes.collectAsState()
    val ghostPointer by viewModel.ghostPointer.collectAsState()
    val telemetryText by viewModel.telemetryText.collectAsState()
    var canvasDimensions by remember { mutableStateOf(Pair(1080f, 1800f)) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "iSWIPE",
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = CyberCyan
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "MACRO",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onOpenSavedGestures) {
                        Icon(Icons.Default.Folder, contentDescription = "Saved Gestures", tint = CyberCyan)
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.LightGray)
                    }
                    IconButton(onClick = onOpenInfo) {
                        Icon(Icons.Default.Info, contentDescription = "App Info", tint = Color.LightGray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepObsidian
                )
            )
        },
        bottomBar = {
            // Action Control Deck
            Surface(
                color = DarkPurpleSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCyan.copy(alpha = 0.2f), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    // Real-time telemetry ticker
                    Text(
                        text = telemetryText,
                        color = CyberCyan.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Control buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Record button
                        Button(
                            onClick = {
                                if (playbackState == PlaybackState.RECORDING) {
                                    viewModel.stopRecording()
                                } else {
                                    viewModel.startRecording()
                                }
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (playbackState == PlaybackState.RECORDING) Color(0xFFFF0055) else ElectricViolet
                            )
                        ) {
                            Icon(
                                if (playbackState == PlaybackState.RECORDING) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                                contentDescription = "Record"
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                if (playbackState == PlaybackState.RECORDING) "STOP" else "RECORD",
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Replay button
                        Button(
                            onClick = {
                                if (playbackState == PlaybackState.PLAYING) {
                                    viewModel.stopReplay()
                                } else {
                                    viewModel.startReplay(canvasDimensions.first, canvasDimensions.second)
                                }
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (playbackState == PlaybackState.PLAYING) CyberCyan else Color(0xFF0077B6)
                            )
                        ) {
                            Icon(
                                if (playbackState == PlaybackState.PLAYING) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Replay",
                                tint = Color.Black
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                if (playbackState == PlaybackState.PLAYING) "HALT" else "REPLAY",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Clear Button
                        OutlinedButton(
                            onClick = { viewModel.clearCanvas() },
                            modifier = Modifier.height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.Gray)
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Clear", tint = Color.White)
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            PracticeCanvas(
                modifier = Modifier.fillMaxSize(),
                activeStrokes = activeStrokes,
                ghostPointer = ghostPointer,
                isRecording = playbackState == PlaybackState.RECORDING,
                onTouchDown = { x, y, nx, ny -> viewModel.onTouchDown(x, y, nx, ny) },
                onTouchMove = { x, y, nx, ny -> viewModel.onTouchMove(x, y, nx, ny) },
                onTouchUp = { x, y, nx, ny -> viewModel.onTouchUp(x, y, nx, ny) },
                onSizeChanged = { w, h -> canvasDimensions = Pair(w, h) }
            )
        }
    }
}
`
    },
    {
      path: 'app/src/main/java/com/iswipemacro/app/ui/theme/Color.kt',
      language: 'kotlin',
      description: 'Gaming color palette: dark purple, obsidian, cyber cyan, and electric violet',
      content: `package com.iswipemacro.app.ui.theme

import androidx.compose.ui.graphics.Color

val DeepObsidian = Color(0xFF090611)
val DarkPurpleSurface = Color(0xFF130D26)
val CyberPurpleCard = Color(0xFF1A1235)
val CyberCyan = Color(0xFF00F0FF)
val NeonCyanLight = Color(0xFF67E8F9)
val ElectricViolet = Color(0xFF9D00FF)
val NeonPinkAccent = Color(0xFFFF007F)
val GridLine = Color(0x1A00F0FF)
`
    },
    {
      path: 'app/src/main/java/com/iswipemacro/app/ui/theme/Theme.kt',
      language: 'kotlin',
      description: 'Material3 dark gaming theme definition',
      content: `package com.iswipemacro.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color.Black,
    primaryContainer = ElectricViolet,
    secondary = NeonCyanLight,
    background = DeepObsidian,
    surface = DarkPurpleSurface,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun ISwipeMacroTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
`
    },
    {
      path: 'app/src/main/java/com/iswipemacro/app/MainActivity.kt',
      language: 'kotlin',
      description: 'Main Activity entry point initializing views and viewmodel',
      content: `package com.iswipemacro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.*
import com.iswipemacro.app.ui.HomeScreen
import com.iswipemacro.app.ui.theme.ISwipeMacroTheme
import com.iswipemacro.app.viewmodel.GestureViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: GestureViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ISwipeMacroTheme {
                HomeScreen(
                    viewModel = viewModel,
                    onOpenSavedGestures = { /* Opens saved gestures bottom sheet */ },
                    onOpenSettings = { /* Opens settings dialog */ },
                    onOpenInfo = { /* Opens app info dialog */ }
                )
            }
        }
    }
}
`
    },
    {
      path: 'app/src/main/res/values/strings.xml',
      language: 'xml',
      description: 'App string resources',
      content: `<resources>
    <string name="app_name">iSwipeMacro</string>
    <string name="record_gesture">Record Gesture</string>
    <string name="replay_gesture">Replay Gesture</string>
    <string name="saved_gestures">Saved Gestures</string>
    <string name="settings">Settings</string>
    <string name="practice_area_desc">Record and replay gestures inside the practice arena</string>
</resources>
`
    },
    {
      path: 'app/src/main/res/values/colors.xml',
      language: 'xml',
      description: 'Resource color definitions',
      content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="deep_obsidian">#090611</color>
    <color name="dark_purple">#130D26</color>
    <color name="cyber_cyan">#00F0FF</color>
    <color name="electric_violet">#9D00FF</color>
</resources>
`
    },
    {
      path: 'app/src/main/res/values/themes.xml',
      language: 'xml',
      description: 'Theme XML style',
      content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.ISwipeMacro" parent="android:Theme.Material.NoActionBar">
        <item name="android:statusBarColor">@color/deep_obsidian</item>
        <item name="android:navigationBarColor">@color/deep_obsidian</item>
        <item name="android:windowBackground">@color/deep_obsidian</item>
    </style>
</resources>
`
    }
  ];
}

export async function generateAndroidProjectZip(): Promise<Blob> {
  const zip = new JSZip();
  const files = getAndroidProjectFiles();

  for (const file of files) {
    zip.file(file.path, file.content);
  }

  const blob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  return blob;
}

export function downloadZipBlob(blob: Blob, filename = 'iSwipeMacro_Android_Studio_Project.zip') {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
