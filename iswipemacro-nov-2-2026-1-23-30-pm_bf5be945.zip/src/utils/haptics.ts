/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type HapticType =
  | 'recordStart'
  | 'recordStop'
  | 'replayStart'
  | 'replayStop'
  | 'pointTouch'
  | 'buttonPress'
  | 'warning';

class HapticsManager {
  private enabled: boolean = true;
  private intensity: 'light' | 'medium' | 'strong' = 'light';
  private listeners: Set<(type: HapticType) => void> = new Set();

  constructor() {
    // Check if vibration is supported
    this.enabled = typeof navigator !== 'undefined' && 'vibrate' in navigator;
  }

  public setEnabled(enabled: boolean) {
    this.enabled = enabled;
  }

  public setIntensity(intensity: 'light' | 'medium' | 'strong') {
    this.intensity = intensity;
  }

  public subscribe(callback: (type: HapticType) => void) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  public trigger(type: HapticType) {
    // Notify visual listeners regardless of hardware vibration support
    this.listeners.forEach((cb) => cb(type));

    if (!this.enabled || typeof navigator === 'undefined' || !('vibrate' in navigator)) {
      return;
    }

    try {
      const multiplier = this.intensity === 'light' ? 0.8 : this.intensity === 'strong' ? 1.4 : 1.0;

      switch (type) {
        case 'recordStart':
          // Subtle double pulse indicating recording is engaged
          navigator.vibrate([Math.round(25 * multiplier), 35, Math.round(25 * multiplier)]);
          break;

        case 'recordStop':
          // Single crisp vibration for recording completion
          navigator.vibrate(Math.round(40 * multiplier));
          break;

        case 'replayStart':
          // Subtle rhythmic buzz welcoming the replay
          navigator.vibrate([Math.round(20 * multiplier), 30, Math.round(30 * multiplier)]);
          break;

        case 'replayStop':
          // Dual short ticks for stop
          navigator.vibrate([Math.round(20 * multiplier), 25, Math.round(20 * multiplier)]);
          break;

        case 'pointTouch':
          // Ultra light micro-tick during high-speed drawing
          navigator.vibrate(Math.round(12 * multiplier));
          break;

        case 'buttonPress':
          // Tactile UI click
          navigator.vibrate(Math.round(18 * multiplier));
          break;

        case 'warning':
          // Danger / alert feedback
          navigator.vibrate([50, 40, 50, 40, 60]);
          break;
      }
    } catch {
      // Ignore vibration errors on unsupported or restricted environments
    }
  }
}

export const haptics = new HapticsManager();
