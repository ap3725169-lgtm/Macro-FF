/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  GestureProfile,
  GestureStroke,
  PlaybackState,
  AppSettings,
  TouchTelemetry,
} from './types/gesture';
import { PRESET_GESTURES } from './data/presetGestures';
import { PracticeCanvas } from './components/PracticeCanvas';
import { SavedGesturesModal } from './components/SavedGesturesModal';
import { SettingsModal } from './components/SettingsModal';
import { AndroidProjectModal } from './components/AndroidProjectModal';
import { AppInfoModal } from './components/AppInfoModal';
import { SaveGestureDialog } from './components/SaveGestureDialog';
import { haptics } from './utils/haptics';
import { sound } from './utils/sound';
import {
  Play,
  Square,
  Circle,
  Folder,
  Settings,
  Info,
  Download,
  Trash2,
  BookmarkPlus,
  Maximize2,
  Minimize2,
  Smartphone,
  Gauge,
  Activity,
  Layers,
  Sparkles,
  Wifi,
  Battery,
} from 'lucide-react';

const STORAGE_KEY_PROFILES = 'iswipemacro_saved_profiles_v1';
const STORAGE_KEY_SETTINGS = 'iswipemacro_settings_v1';

const DEFAULT_SETTINGS: AppSettings = {
  replaySpeed: 1.0,
  repeatCount: 1,
  repeatDelayMs: 300,
  hapticsEnabled: true,
  hapticIntensity: 'light',
  soundEnabled: true,
  trailStyle: 'neon-cyan',
  showCoordinatesHUD: true,
  showVelocityVector: true,
  showGhostPointer: true,
  showGridLines: true,
  deviceFrame: 'redmi-note-11t',
};

export default function App() {
  // Profiles state with local persistence
  const [savedProfiles, setSavedProfiles] = useState<GestureProfile[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_PROFILES);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Fallback
    }
    return PRESET_GESTURES;
  });

  // Settings state
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_SETTINGS);
      if (stored) return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
    } catch {
      // Fallback
    }
    return DEFAULT_SETTINGS;
  });

  // Active gesture & playback state
  const [selectedProfile, setSelectedProfile] = useState<GestureProfile | null>(() => PRESET_GESTURES[0] || null);
  const [activeStrokes, setActiveStrokes] = useState<GestureStroke[]>(() => PRESET_GESTURES[0]?.strokes || []);
  const [playbackState, setPlaybackState] = useState<PlaybackState>('idle');

  // Real-time telemetry
  const [telemetry, setTelemetry] = useState<TouchTelemetry>({
    currentX: 0,
    currentY: 0,
    currentNx: 0,
    currentNy: 0,
    velocity: 0,
    fps: 60,
    samplingRate: 90,
    activeStrokesCount: 0,
    elapsedMs: 0,
  });

  // Modals
  const [isSavedModalOpen, setIsSavedModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState(false);
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false);

  // Sync settings and profiles to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PROFILES, JSON.stringify(savedProfiles));
    } catch {
      // Quota exceeded
    }
  }, [savedProfiles]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
    } catch {
      // Ignore
    }
    haptics.setEnabled(settings.hapticsEnabled);
    haptics.setIntensity(settings.hapticIntensity);
    sound.setEnabled(settings.soundEnabled);
  }, [settings]);

  // Handle Record Action
  const handleStartRecording = () => {
    if (playbackState === 'playing') {
      handleStopReplay();
    }
    setActiveStrokes([]);
    setSelectedProfile(null);
    setPlaybackState('recording');

    // Subtle vibration when user starts recording
    if (settings.hapticsEnabled) {
      haptics.trigger('recordStart');
    }
    if (settings.soundEnabled) {
      sound.playRecordStart();
    }
  };

  const handleStopRecording = () => {
    if (playbackState !== 'recording') return;
    setPlaybackState('idle');

    // Subtle vibration when user stops recording
    if (settings.hapticsEnabled) {
      haptics.trigger('recordStop');
    }
    if (settings.soundEnabled) {
      sound.playRecordStop();
    }
  };

  // Handle Replay Action
  const handleStartReplay = () => {
    if (activeStrokes.length === 0) return;
    if (playbackState === 'recording') {
      handleStopRecording();
    }
    setPlaybackState('playing');

    // Subtle vibration when replay begins
    if (settings.hapticsEnabled) {
      haptics.trigger('replayStart');
    }
    if (settings.soundEnabled) {
      sound.playReplayStart();
    }
  };

  const handleStopReplay = () => {
    if (playbackState !== 'playing') return;
    setPlaybackState('idle');

    // Subtle vibration when replay is stopped
    if (settings.hapticsEnabled) {
      haptics.trigger('replayStop');
    }
    if (settings.soundEnabled) {
      sound.playReplayStop();
    }
  };

  const handleClearCanvas = () => {
    handleStopReplay();
    handleStopRecording();
    setActiveStrokes([]);
    setSelectedProfile(null);
    haptics.trigger('buttonPress');
    if (settings.soundEnabled) sound.playClick();
  };

  // Profile operations
  const handleSaveProfile = (name: string, category: GestureProfile['category']) => {
    const totalPts = activeStrokes.reduce((acc, s) => acc + s.points.length, 0);
    const totalDist = activeStrokes.reduce((acc, s) => acc + s.lengthPx, 0);
    const duration = activeStrokes.length > 0 ? Math.max(...activeStrokes.map((s) => s.endTime)) : 0;
    const avgVelocity = duration > 0 ? Math.round(totalDist / (duration / 1000)) : 0;

    const newProfile: GestureProfile = {
      id: `profile-${Date.now()}`,
      name,
      description: `Recorded gesture profile with ${activeStrokes.length} stroke(s) and ${totalPts} points.`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      durationMs: duration,
      strokes: activeStrokes,
      totalPoints: totalPts,
      totalDistancePx: totalDist,
      averageVelocityPxPerSec: avgVelocity,
      category,
      color: settings.trailStyle === 'cyber-purple' ? '#9D00FF' : '#00F0FF',
      deviceSource: 'Redmi Note 11T 5G (FHD+)',
    };

    setSavedProfiles((prev) => [newProfile, ...prev]);
    setSelectedProfile(newProfile);
  };

  const handleDeleteProfile = (id: string) => {
    setSavedProfiles((prev) => prev.filter((p) => p.id !== id));
    if (selectedProfile?.id === id) {
      setSelectedProfile(null);
    }
  };

  const handleRenameProfile = (id: string, newName: string) => {
    setSavedProfiles((prev) =>
      prev.map((p) => (p.id === id ? { ...p, name: newName, updatedAt: Date.now() } : p))
    );
    if (selectedProfile?.id === id) {
      setSelectedProfile((prev) => (prev ? { ...prev, name: newName } : null));
    }
  };

  const handleDuplicateProfile = (profile: GestureProfile) => {
    const dup: GestureProfile = {
      ...profile,
      id: `profile-${Date.now()}`,
      name: `${profile.name} (Copy)`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setSavedProfiles((prev) => [dup, ...prev]);
  };

  const handleSelectProfile = (profile: GestureProfile) => {
    handleStopReplay();
    handleStopRecording();
    setSelectedProfile(profile);
    setActiveStrokes(profile.strokes);
    haptics.trigger('buttonPress');
    if (settings.soundEnabled) sound.playClick();
  };

  const handleQuickReplay = (profile: GestureProfile) => {
    handleSelectProfile(profile);
    setTimeout(() => {
      setPlaybackState('playing');
      if (settings.hapticsEnabled) haptics.trigger('replayStart');
      if (settings.soundEnabled) sound.playReplayStart();
    }, 100);
  };

  const handleImportProfiles = (imported: GestureProfile[]) => {
    setSavedProfiles((prev) => [...imported, ...prev]);
    if (imported[0]) {
      handleSelectProfile(imported[0]);
    }
  };

  const handleClearAllProfiles = () => {
    setSavedProfiles([]);
    setSelectedProfile(null);
    setActiveStrokes([]);
  };

  const totalPointsCount = activeStrokes.reduce((acc, s) => acc + s.points.length, 0);
  const totalLengthPx = Math.round(activeStrokes.reduce((acc, s) => acc + s.lengthPx, 0));
  const activeDurationMs = activeStrokes.length > 0 ? Math.max(...activeStrokes.map((s) => s.endTime)) : 0;

  return (
    <div className="min-h-screen bg-[#07040D] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Top Bar - Clean One-Row Contract */}
      <header className="h-16 px-4 md:px-8 border-b border-purple-900/40 bg-[#0E091D]/90 backdrop-blur-md flex items-center justify-between gap-4 shrink-0 z-30">
        
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3">
          <img
            src="/src/assets/images/iswipemacro_app_icon_1793605461440.jpg"
            alt="iSwipeMacro Icon"
            referrerPolicy="no-referrer"
            className="w-10 h-10 rounded-xl border border-cyan-500/40 shadow-[0_0_12px_rgba(0,240,255,0.25)] object-cover"
          />
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-lg font-black tracking-wider text-cyan-400 font-heading">iSWIPE</span>
              <span className="text-lg font-bold tracking-wider text-white font-heading">MACRO</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-slate-400">
              <span>Android Gesture Studio</span>
              <span aria-hidden="true">·</span>
              <span className="text-cyan-400/90 font-mono-numbers">Redmi Note 11T 5G</span>
            </div>
          </div>
        </div>

        {/* Zone 2: Navigation Links / Actions */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-300">
          <button
            onClick={() => setIsSavedModalOpen(true)}
            className="hover:text-cyan-400 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Folder className="w-4 h-4 text-cyan-400" />
            <span>Saved Gestures ({savedProfiles.length})</span>
          </button>

          <button
            onClick={() => setIsSettingsModalOpen(true)}
            className="hover:text-cyan-400 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Settings className="w-4 h-4 text-purple-400" />
            <span>Settings & Haptics</span>
          </button>

          <button
            onClick={() => setIsInfoModalOpen(true)}
            className="hover:text-cyan-400 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Info className="w-4 h-4 text-slate-400" />
            <span>App Specs</span>
          </button>
        </nav>

        {/* Zone 3: Primary Action CTA */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsAndroidModalOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs flex items-center gap-2 shadow-[0_0_15px_rgba(0,240,255,0.3)] transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span className="hidden sm:inline">Android Studio Project</span>
            <span className="sm:hidden">Export APK</span>
          </button>
        </div>
      </header>

      {/* Main Workspace Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Device Canvas & Practice Arena (Cols 7 on Desktop) */}
        <div className="lg:col-span-7 flex flex-col items-center w-full">
          
          {/* Frame Container - Redmi Note 11T 5G Smartphone Frame */}
          <div
            className={`w-full transition-all duration-300 ${
              settings.deviceFrame === 'redmi-note-11t'
                ? 'max-w-[400px] aspect-[9/19] rounded-[44px] p-3 bg-gradient-to-b from-[#1C1530] via-[#0D081B] to-[#120B24] border-[3px] border-[#37245A] shadow-[0_0_50px_rgba(157,0,255,0.15)] flex flex-col relative'
                : settings.deviceFrame === 'standard-phone'
                ? 'max-w-[390px] aspect-[9/16] rounded-3xl p-3 bg-[#110B22] border-2 border-purple-900/60 shadow-xl flex flex-col relative'
                : 'w-full h-[640px] rounded-2xl bg-[#0F0A1D] border border-purple-900/50 p-2 flex flex-col relative'
            }`}
          >
            {/* Phone Bezel Notch / Punch-Hole for Redmi Note 11T 5G */}
            {settings.deviceFrame === 'redmi-note-11t' && (
              <div className="relative w-full pt-1 pb-2 flex items-center justify-between px-6 shrink-0 select-none text-[11px] font-mono-numbers text-slate-400">
                <span>09:41</span>
                {/* Centered Camera Punch Hole */}
                <div className="w-3.5 h-3.5 rounded-full bg-black border border-slate-800 shadow-inner flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-950/80"></div>
                </div>
                <div className="flex items-center gap-1.5 text-slate-300">
                  <span className="text-[9px] font-bold text-cyan-400">90Hz 5G</span>
                  <Wifi className="w-3 h-3 text-slate-300" />
                  <Battery className="w-3.5 h-3.5 text-slate-300" />
                </div>
              </div>
            )}

            {/* Interactive Practice Canvas Surface */}
            <div className="flex-1 relative w-full h-full min-h-[360px] overflow-hidden rounded-2xl">
              <PracticeCanvas
                playbackState={playbackState}
                activeStrokes={activeStrokes}
                onStrokesChange={(strokes) => {
                  setActiveStrokes(strokes);
                  setSelectedProfile(null);
                }}
                settings={settings}
                onTelemetryUpdate={setTelemetry}
                onRecordingComplete={handleStopRecording}
                onReplayComplete={handleStopReplay}
              />
            </div>

            {/* Bottom Quick Controls Deck */}
            <div className="pt-3 pb-1 shrink-0 space-y-2">
              
              {/* Main Action Trigger Buttons */}
              <div className="grid grid-cols-3 gap-2">
                
                {/* Record Button */}
                {playbackState === 'recording' ? (
                  <button
                    onClick={handleStopRecording}
                    className="py-3 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(244,63,94,0.4)] transition-transform active:scale-95 cursor-pointer animate-pulse"
                  >
                    <Square className="w-4 h-4 fill-current" />
                    <span>STOP REC</span>
                  </button>
                ) : (
                  <button
                    onClick={handleStartRecording}
                    className="py-3 px-3 rounded-xl bg-purple-700 hover:bg-purple-600 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(157,0,255,0.3)] transition-transform active:scale-95 cursor-pointer"
                  >
                    <Circle className="w-4 h-4 fill-rose-500 text-rose-500" />
                    <span>RECORD</span>
                  </button>
                )}

                {/* Replay Button */}
                {playbackState === 'playing' ? (
                  <button
                    onClick={handleStopReplay}
                    className="py-3 px-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,240,255,0.4)] transition-transform active:scale-95 cursor-pointer"
                  >
                    <Square className="w-4 h-4 fill-current" />
                    <span>HALT</span>
                  </button>
                ) : (
                  <button
                    onClick={handleStartReplay}
                    disabled={activeStrokes.length === 0}
                    className="py-3 px-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,240,255,0.3)] transition-transform active:scale-95 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>REPLAY</span>
                  </button>
                )}

                {/* Clear Button */}
                <button
                  onClick={handleClearCanvas}
                  disabled={activeStrokes.length === 0 && playbackState === 'idle'}
                  className="py-3 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>CLEAR</span>
                </button>
              </div>

              {/* Save Gesture Trigger (when uncommitted gesture is on canvas) */}
              {activeStrokes.length > 0 && playbackState === 'idle' && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsSaveDialogOpen(true)}
                    className="w-full py-2 px-3 rounded-xl bg-[#1A1230] hover:bg-[#251A45] border border-cyan-500/40 text-cyan-300 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm"
                  >
                    <BookmarkPlus className="w-4 h-4" />
                    <span>Save This Recorded Gesture</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Telemetry HUD, Presets & Controls (Cols 5 on Desktop) */}
        <div className="lg:col-span-5 space-y-4 w-full">
          
          {/* Active Gesture Banner */}
          <div className="p-4 rounded-2xl bg-[#0F0A1C] border border-purple-900/40 shadow-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Current Active Target
              </span>
              <span className="text-[11px] font-mono-numbers px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                {selectedProfile ? selectedProfile.category : 'Unsaved Canvas'}
              </span>
            </div>

            <h3 className="text-base font-bold text-white mb-1">
              {selectedProfile ? selectedProfile.name : 'Custom Recorded Gesture'}
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              {selectedProfile
                ? selectedProfile.description
                : 'Gesture points are captured inside the practice area. Replay with original delta timing or modify speed multiplier below.'}
            </p>

            {/* Quick Speed Selector Bar */}
            <div className="mt-3 pt-3 border-t border-purple-900/30 flex items-center justify-between">
              <span className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
                <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                Replay Speed:
              </span>
              <div className="flex items-center gap-1">
                {[0.5, 1.0, 1.5, 2.0, 3.0].map((spd) => (
                  <button
                    key={spd}
                    onClick={() => {
                      setSettings((prev) => ({ ...prev, replaySpeed: spd }));
                      haptics.trigger('buttonPress');
                    }}
                    className={`px-2 py-1 rounded text-[11px] font-mono-numbers transition-all cursor-pointer ${
                      settings.replaySpeed === spd
                        ? 'bg-cyan-500 text-black font-bold shadow-sm'
                        : 'bg-[#140D26] text-slate-400 hover:text-white'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Telemetry HUD Card */}
          <div className="p-4 rounded-2xl bg-[#0F0A1C] border border-purple-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">Touch Telemetry HUD</span>
              </div>
              <span className="text-[10px] font-mono-numbers text-emerald-400 font-bold">
                {telemetry.fps} FPS · {telemetry.samplingRate}Hz
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              <div className="p-2.5 rounded-xl bg-[#140D26] border border-purple-900/40">
                <span className="text-[10px] text-slate-500 uppercase block">Coordinates</span>
                <span className="text-xs font-mono-numbers text-cyan-300 font-bold block mt-0.5">
                  X:{telemetry.currentX} Y:{telemetry.currentY}
                </span>
                <span className="text-[9px] font-mono-numbers text-slate-500 block">
                  [{telemetry.currentNx}, {telemetry.currentNy}]
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-[#140D26] border border-purple-900/40">
                <span className="text-[10px] text-slate-500 uppercase block">Stroke Points</span>
                <span className="text-xs font-mono-numbers text-white font-bold block mt-0.5">
                  {totalPointsCount}
                </span>
                <span className="text-[9px] font-mono-numbers text-slate-500 block">
                  {activeStrokes.length} stroke segment(s)
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-[#140D26] border border-purple-900/40">
                <span className="text-[10px] text-slate-500 uppercase block">Total Duration</span>
                <span className="text-xs font-mono-numbers text-white font-bold block mt-0.5">
                  {activeDurationMs}ms
                </span>
                <span className="text-[9px] font-mono-numbers text-slate-500 block">
                  {(activeDurationMs / 1000).toFixed(2)}s elapsed
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-[#140D26] border border-purple-900/40">
                <span className="text-[10px] text-slate-500 uppercase block">Swipe Distance</span>
                <span className="text-xs font-mono-numbers text-white font-bold block mt-0.5">
                  {totalLengthPx} px
                </span>
                <span className="text-[9px] font-mono-numbers text-slate-500 block">
                  Trajectory length
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-[#140D26] border border-purple-900/40">
                <span className="text-[10px] text-slate-500 uppercase block">Current Velocity</span>
                <span className="text-xs font-mono-numbers text-cyan-300 font-bold block mt-0.5">
                  {telemetry.velocity} px/s
                </span>
                <span className="text-[9px] font-mono-numbers text-slate-500 block">
                  Instantaneous speed
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-[#140D26] border border-purple-900/40">
                <span className="text-[10px] text-slate-500 uppercase block">Haptic Status</span>
                <span className={`text-xs font-bold block mt-0.5 ${settings.hapticsEnabled ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {settings.hapticsEnabled ? 'Tactile ON' : 'Disabled'}
                </span>
                <span className="text-[9px] text-slate-500 block capitalize">
                  {settings.hapticIntensity} pulse
                </span>
              </div>
            </div>
          </div>

          {/* Presets Quick Drawer */}
          <div className="p-4 rounded-2xl bg-[#0F0A1C] border border-purple-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">Fast Replay Presets</span>
              </div>
              <button
                onClick={() => setIsSavedModalOpen(true)}
                className="text-xs text-cyan-400 hover:underline cursor-pointer"
              >
                View All ({savedProfiles.length})
              </button>
            </div>

            <div className="space-y-2">
              {savedProfiles.slice(0, 3).map((profile) => (
                <div
                  key={profile.id}
                  className="p-3 rounded-xl bg-[#140D26] hover:bg-[#1A1230] border border-purple-900/30 flex items-center justify-between gap-3 transition-colors"
                >
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-white truncate">{profile.name}</h4>
                    <div className="flex items-center gap-2 text-[10px] font-mono-numbers text-slate-400 mt-0.5">
                      <span>{profile.durationMs}ms</span>
                      <span>·</span>
                      <span>{profile.totalPoints} pts</span>
                      <span>·</span>
                      <span className="text-cyan-400">{profile.category}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleQuickReplay(profile)}
                    className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center gap-1 transition-transform active:scale-95 cursor-pointer shrink-0"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    Play
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Android Studio Export Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/60 to-cyan-950/40 border border-cyan-500/30 flex items-center justify-between gap-4">
            <div>
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                Need Real Android APK?
              </h4>
              <p className="text-[11px] text-slate-300 mt-0.5">
                Download the complete Android Studio Kotlin project with Gradle build scripts.
              </p>
            </div>
            <button
              onClick={() => setIsAndroidModalOpen(true)}
              className="px-3 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs shrink-0 cursor-pointer shadow-sm"
            >
              Inspect & ZIP
            </button>
          </div>
        </div>
      </main>

      {/* Mobile Floating Action Bottom Bar */}
      <footer className="md:hidden sticky bottom-0 z-40 bg-[#0F0A1C]/95 backdrop-blur-md border-t border-purple-900/50 px-4 py-2 flex items-center justify-around">
        <button
          onClick={() => setIsSavedModalOpen(true)}
          className="flex flex-col items-center gap-1 text-slate-400 hover:text-white cursor-pointer"
        >
          <Folder className="w-5 h-5 text-cyan-400" />
          <span className="text-[10px] font-medium">Gestures</span>
        </button>

        <button
          onClick={() => setIsSettingsModalOpen(true)}
          className="flex flex-col items-center gap-1 text-slate-400 hover:text-white cursor-pointer"
        >
          <Settings className="w-5 h-5 text-purple-400" />
          <span className="text-[10px] font-medium">Settings</span>
        </button>

        <button
          onClick={() => setIsAndroidModalOpen(true)}
          className="flex flex-col items-center gap-1 text-slate-400 hover:text-white cursor-pointer"
        >
          <Download className="w-5 h-5 text-emerald-400" />
          <span className="text-[10px] font-medium">APK Project</span>
        </button>

        <button
          onClick={() => setIsInfoModalOpen(true)}
          className="flex flex-col items-center gap-1 text-slate-400 hover:text-white cursor-pointer"
        >
          <Info className="w-5 h-5 text-slate-400" />
          <span className="text-[10px] font-medium">About</span>
        </button>
      </footer>

      {/* Modals & Dialogs */}
      <SavedGesturesModal
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        savedProfiles={savedProfiles}
        selectedProfile={selectedProfile}
        onSelectProfile={handleSelectProfile}
        onDeleteProfile={handleDeleteProfile}
        onRenameProfile={handleRenameProfile}
        onDuplicateProfile={handleDuplicateProfile}
        onImportProfiles={handleImportProfiles}
        onQuickReplay={handleQuickReplay}
      />

      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        onUpdateSettings={(newSettings) => setSettings((prev) => ({ ...prev, ...newSettings }))}
        onClearAllProfiles={handleClearAllProfiles}
      />

      <AndroidProjectModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
      />

      <AppInfoModal
        isOpen={isInfoModalOpen}
        onClose={() => setIsInfoModalOpen(false)}
      />

      <SaveGestureDialog
        isOpen={isSaveDialogOpen}
        onClose={() => setIsSaveDialogOpen(false)}
        strokes={activeStrokes}
        onSave={handleSaveProfile}
      />
    </div>
  );
}
