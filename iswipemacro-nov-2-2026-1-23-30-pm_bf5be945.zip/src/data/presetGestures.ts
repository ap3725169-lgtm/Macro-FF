/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GestureProfile, GestureStroke, TouchPoint } from '../types/gesture';

function generateFlickPoints(): GestureStroke[] {
  const points: TouchPoint[] = [];
  const startX = 0.5;
  const startY = 0.75;
  const endX = 0.5;
  const endY = 0.25;
  const steps = 30;
  const duration = 280;

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    // Ease out cubic
    const ease = 1 - Math.pow(1 - t, 3);
    const nx = startX + (endX - startX) * ease;
    const ny = startY + (endY - startY) * ease;
    const timestamp = Math.round(t * duration);
    const type = i === 0 ? 'down' : i === steps ? 'up' : 'move';
    points.push({
      x: nx * 380,
      y: ny * 600,
      nx,
      ny,
      timestamp,
      type,
      pressure: 0.8 - t * 0.3,
      velocity: 1800 * (1 - t * 0.7),
    });
  }

  return [{
    id: 'stroke-flick-1',
    points,
    startTime: 0,
    endTime: duration,
    lengthPx: 300,
  }];
}

function generateMobaArcPoints(): GestureStroke[] {
  const points: TouchPoint[] = [];
  const steps = 45;
  const duration = 650;

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    // Arc from bottom left (0.25, 0.7) to top right (0.8, 0.3) with curve
    const angle = Math.PI * 0.6 * t;
    const nx = 0.25 + 0.55 * Math.sin(angle);
    const ny = 0.75 - 0.45 * (1 - Math.cos(angle * 0.8));
    const timestamp = Math.round(t * duration);
    const type = i === 0 ? 'down' : i === steps ? 'up' : 'move';

    points.push({
      x: nx * 380,
      y: ny * 600,
      nx: Math.max(0.05, Math.min(0.95, nx)),
      ny: Math.max(0.05, Math.min(0.95, ny)),
      timestamp,
      type,
      pressure: 0.75,
      velocity: 850,
    });
  }

  return [{
    id: 'stroke-moba-arc-1',
    points,
    startTime: 0,
    endTime: duration,
    lengthPx: 420,
  }];
}

function generateZigZagPoints(): GestureStroke[] {
  const points: TouchPoint[] = [];
  const waypoints = [
    { nx: 0.2, ny: 0.8 },
    { nx: 0.8, ny: 0.65 },
    { nx: 0.2, ny: 0.5 },
    { nx: 0.8, ny: 0.35 },
    { nx: 0.5, ny: 0.2 },
  ];
  const durationTotal = 850;
  const stepsPerLeg = 12;
  let currentTimestamp = 0;

  for (let leg = 0; leg < waypoints.length - 1; leg++) {
    const w1 = waypoints[leg];
    const w2 = waypoints[leg + 1];
    const legDuration = durationTotal / (waypoints.length - 1);

    for (let i = (leg === 0 ? 0 : 1); i <= stepsPerLeg; i++) {
      const t = i / stepsPerLeg;
      const nx = w1.nx + (w2.nx - w1.nx) * t;
      const ny = w1.ny + (w2.ny - w1.ny) * t;
      const timestamp = Math.round(currentTimestamp + t * legDuration);
      const isStart = leg === 0 && i === 0;
      const isEnd = leg === waypoints.length - 2 && i === stepsPerLeg;

      points.push({
        x: nx * 380,
        y: ny * 600,
        nx,
        ny,
        timestamp,
        type: isStart ? 'down' : isEnd ? 'up' : 'move',
        pressure: 0.85,
        velocity: 1100,
      });
    }
    currentTimestamp += legDuration;
  }

  return [{
    id: 'stroke-zigzag-1',
    points,
    startTime: 0,
    endTime: Math.round(currentTimestamp),
    lengthPx: 640,
  }];
}

export const PRESET_GESTURES: GestureProfile[] = [
  {
    id: 'preset-fps-flick',
    name: 'FPS Quick Snap 90°',
    description: 'Instant vertical snap flick gesture designed for tactical shooter aim alignment.',
    createdAt: Date.now() - 3600000 * 24,
    updatedAt: Date.now() - 3600000 * 24,
    durationMs: 280,
    strokes: generateFlickPoints(),
    totalPoints: 31,
    totalDistancePx: 300,
    averageVelocityPxPerSec: 1071,
    category: 'FPS',
    color: '#00F0FF',
    deviceSource: 'Redmi Note 11T 5G (FHD+)',
  },
  {
    id: 'preset-moba-arc',
    name: 'MOBA Skillshot Arc',
    description: 'Curved predictive skillshot targeting path with sustained drag trajectory.',
    createdAt: Date.now() - 3600000 * 12,
    updatedAt: Date.now() - 3600000 * 12,
    durationMs: 650,
    strokes: generateMobaArcPoints(),
    totalPoints: 46,
    totalDistancePx: 420,
    averageVelocityPxPerSec: 646,
    category: 'MOBA',
    color: '#A855F7',
    deviceSource: 'Redmi Note 11T 5G (FHD+)',
  },
  {
    id: 'preset-zigzag-dodge',
    name: 'Battle Royale Zig-Zag Dodge',
    description: 'Rapid evasion zig-zag path to test multi-directional thumb reaction speed.',
    createdAt: Date.now() - 3600000 * 4,
    updatedAt: Date.now() - 3600000 * 4,
    durationMs: 850,
    strokes: generateZigZagPoints(),
    totalPoints: 49,
    totalDistancePx: 640,
    averageVelocityPxPerSec: 752,
    category: 'Battle Royale',
    color: '#3B82F6',
    deviceSource: 'Redmi Note 11T 5G (FHD+)',
  },
];
