/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface TouchPoint {
  x: number; // Screen X
  y: number; // Screen Y
  nx: number; // Normalized X (0.0 to 1.0) for resolution-independent playback
  ny: number; // Normalized Y (0.0 to 1.0)
  timestamp: number; // Relative ms from start of recording
  type: 'down' | 'move' | 'up';
  pressure?: number; // 0.0 to 1.0
  velocity?: number; // px/s
}

export interface GestureStroke {
  id: string;
  points: TouchPoint[];
  startTime: number;
  endTime: number;
  lengthPx: number;
}

export interface GestureProfile {
  id: string;
  name: string;
  description: string;
  createdAt: number;
  updatedAt: number;
  durationMs: number;
  strokes: GestureStroke[];
  totalPoints: number;
  totalDistancePx: number;
  averageVelocityPxPerSec: number;
  category: 'FPS' | 'MOBA' | 'Battle Royale' | 'Rhythm' | 'General';
  color: string;
  deviceSource?: string;
}

export type PlaybackState = 'idle' | 'recording' | 'playing' | 'paused';

export interface AppSettings {
  replaySpeed: number; // 0.25 to 5.0
  repeatCount: number; // 1 to 20, or -1 for infinite
  repeatDelayMs: number; // delay between loops in ms
  hapticsEnabled: boolean; // subtle vibration
  hapticIntensity: 'light' | 'medium' | 'strong';
  soundEnabled: boolean; // synthesized web audio ticks & swooshes
  trailStyle: 'neon-cyan' | 'cyber-purple' | 'matrix-green' | 'solar-gold';
  showCoordinatesHUD: boolean;
  showVelocityVector: boolean;
  showGhostPointer: boolean;
  showGridLines: boolean;
  deviceFrame: 'redmi-note-11t' | 'standard-phone' | 'fullscreen';
}

export interface TouchTelemetry {
  currentX: number;
  currentY: number;
  currentNx: number;
  currentNy: number;
  velocity: number;
  fps: number;
  samplingRate: number;
  activeStrokesCount: number;
  elapsedMs: number;
}
