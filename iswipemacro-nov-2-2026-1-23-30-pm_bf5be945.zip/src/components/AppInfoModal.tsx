/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Info, ShieldCheck, Smartphone, Zap, Sparkles, X, CheckCircle2 } from 'lucide-react';

interface AppInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppInfoModal: React.FC<AppInfoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-[#0F0A1C] border border-cyan-500/30 rounded-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden text-slate-100">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-purple-900/40 bg-[#140D26]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Info className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-wide">About iSwipeMacro</h2>
              <p className="text-xs text-slate-400">Version 1.0.0 · Mobile Practice Studio</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-lg hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          <div className="p-4 rounded-xl bg-[#140D26] border border-purple-900/40 space-y-2">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
              <Zap className="w-4 h-4" />
              <span>Next-Gen Gaming Gesture Simulator</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              <strong>iSwipeMacro</strong> is an advanced gesture-recording and practice application crafted with a dark gaming HUD aesthetic, dark obsidian & purple backdrops, and luminous neon cyan highlights.
            </p>
          </div>

          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Core Capabilities</h4>
            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2.5 p-2.5 rounded-lg bg-[#140D26] border border-purple-900/30">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">Precision Gesture Recording:</strong> Captures touch coordinates, delta timing, velocity, and swipe arcs with sub-pixel resolution.
                </div>
              </div>
              <div className="flex items-start gap-2.5 p-2.5 rounded-lg bg-[#140D26] border border-purple-900/30">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">Visual Replay Engine:</strong> Ghost touch pointer accurately re-enacts gestures with original timing, variable speeds (0.25x to 5.0x), and repeat loops.
                </div>
              </div>
              <div className="flex items-start gap-2.5 p-2.5 rounded-lg bg-[#140D26] border border-purple-900/30">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">Subtle Haptic Feedback:</strong> Non-intrusive vibration patterns on record start, record stop, replay begin, and replay halt.
                </div>
              </div>
              <div className="flex items-start gap-2.5 p-2.5 rounded-lg bg-[#140D26] border border-purple-900/30">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">Local Profile Management:</strong> Save, rename, duplicate, export, and delete profiles stored securely on the device.
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#140D26] border border-purple-900/40 space-y-1.5">
            <div className="flex items-center gap-2 text-white font-bold text-xs">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              <span>Redmi Note 11T 5G Optimization</span>
            </div>
            <p className="text-xs text-slate-300">
              Tailored for 20:9 FHD+ screens (1080 × 2400 pixels) with 90Hz AdaptiveSync refresh and high-frequency touch polling. Coordinates use normalized relative vectors (<code>nx</code>, <code>ny</code>) so gestures replay with accuracy across all screen dimensions.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-purple-950/20 border border-purple-800/40 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-white">Standalone Practice Environment & Privacy</h4>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                iSwipeMacro is strictly a standalone practice tool. Gestures are recorded and replayed solely inside its dedicated practice surface. It does not inject input into third-party games or applications, requires no root access, and accesses no personal data.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-purple-900/40 bg-[#120B22] flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs transition-colors cursor-pointer"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
