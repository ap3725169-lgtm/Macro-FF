/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GestureStroke, GestureProfile } from '../types/gesture';
import { haptics } from '../utils/haptics';
import { sound } from '../utils/sound';
import { BookmarkPlus, X, Check } from 'lucide-react';

interface SaveGestureDialogProps {
  isOpen: boolean;
  onClose: () => void;
  strokes: GestureStroke[];
  onSave: (name: string, category: GestureProfile['category']) => void;
}

export const SaveGestureDialog: React.FC<SaveGestureDialogProps> = ({
  isOpen,
  onClose,
  strokes,
  onSave,
}) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<GestureProfile['category']>('General');

  if (!isOpen) return null;

  const totalPoints = strokes.reduce((acc, s) => acc + s.points.length, 0);
  const totalDist = strokes.reduce((acc, s) => acc + s.lengthPx, 0);
  const duration = strokes.length > 0 ? Math.max(...strokes.map((s) => s.endTime)) : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = name.trim() || `Gesture #${Date.now().toString().slice(-4)}`;
    onSave(finalName, category);
    haptics.trigger('buttonPress');
    sound.playClick();
    setName('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#0F0A1C] border border-cyan-500/40 rounded-2xl shadow-2xl overflow-hidden text-slate-100">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-purple-900/40 bg-[#140D26]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <BookmarkPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Save Gesture Profile</h2>
              <p className="text-[11px] text-slate-400">Store this gesture for visual replay and practice</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {/* Quick Metrics Badge */}
          <div className="p-3 rounded-xl bg-[#080511] border border-purple-900/40 flex items-center justify-between text-xs font-mono-numbers">
            <div className="text-slate-400">
              Duration: <span className="text-cyan-300 font-bold">{duration}ms</span>
            </div>
            <div className="text-slate-400">
              Points: <span className="text-cyan-300 font-bold">{totalPoints}</span>
            </div>
            <div className="text-slate-400">
              Length: <span className="text-cyan-300 font-bold">{Math.round(totalDist)}px</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Gesture Profile Name
            </label>
            <input
              type="text"
              placeholder="e.g. Apex 180 Flick, Quick Skillshot..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#140D26] border border-purple-900/50 text-sm text-white focus:outline-none focus:border-cyan-500/80"
              autoFocus
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Category
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['FPS', 'MOBA', 'Battle Royale', 'Rhythm', 'General'] as const).map((cat) => (
                <button
                  type="button"
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`px-3 py-2 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    category === cat
                      ? 'bg-cyan-500 text-black font-bold shadow-[0_0_10px_rgba(0,240,255,0.3)]'
                      : 'bg-[#140D26] border border-purple-900/40 text-slate-400 hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-slate-300 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs flex items-center gap-1.5 shadow-[0_0_15px_rgba(0,240,255,0.3)] cursor-pointer"
            >
              <Check className="w-4 h-4 stroke-[2.5]" />
              Save Profile
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
