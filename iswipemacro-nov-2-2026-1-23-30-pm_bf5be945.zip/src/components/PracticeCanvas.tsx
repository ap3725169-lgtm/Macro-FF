/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { TouchPoint, GestureStroke, PlaybackState, AppSettings, TouchTelemetry } from '../types/gesture';
import { haptics } from '../utils/haptics';
import { sound } from '../utils/sound';

interface PracticeCanvasProps {
  playbackState: PlaybackState;
  activeStrokes: GestureStroke[];
  onStrokesChange: (strokes: GestureStroke[]) => void;
  settings: AppSettings;
  onTelemetryUpdate: (telemetry: TouchTelemetry) => void;
  onRecordingComplete: () => void;
  onReplayComplete: () => void;
}

export const PracticeCanvas: React.FC<PracticeCanvasProps> = ({
  playbackState,
  activeStrokes,
  onStrokesChange,
  settings,
  onTelemetryUpdate,
  onRecordingComplete,
  onReplayComplete,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Replay animation state
  const replayAnimIdRef = useRef<number | null>(null);
  const replayStartTimeRef = useRef<number>(0);
  const replayLoopCountRef = useRef<number>(0);

  // Active recording in progress
  const isPointerDownRef = useRef<boolean>(false);
  const recordingStartTimestampRef = useRef<number>(0);
  const currentStrokePointsRef = useRef<TouchPoint[]>([]);
  const lastPointTimeRef = useRef<number>(0);

  // Ghost pointer state for replay rendering
  const ghostPointerRef = useRef<{ x: number; y: number; pressure: number; active: boolean } | null>(null);

  // Telemetry tracking
  const frameCountRef = useRef<number>(0);
  const lastFpsCheckRef = useRef<number>(performance.now());
  const currentFpsRef = useRef<number>(60);

  // Color schemes based on settings.trailStyle
  const getTrailColors = useCallback(() => {
    switch (settings.trailStyle) {
      case 'cyber-purple':
        return {
          glow: 'rgba(157, 0, 255, 0.4)',
          stroke: '#C084FC',
          core: '#FFFFFF',
          reticle: '#9D00FF',
        };
      case 'matrix-green':
        return {
          glow: 'rgba(0, 255, 136, 0.4)',
          stroke: '#4ADE80',
          core: '#FFFFFF',
          reticle: '#00FF88',
        };
      case 'solar-gold':
        return {
          glow: 'rgba(255, 187, 0, 0.4)',
          stroke: '#FBBF24',
          core: '#FFFFFF',
          reticle: '#FFB800',
        };
      case 'neon-cyan':
      default:
        return {
          glow: 'rgba(0, 240, 255, 0.45)',
          stroke: '#22D3EE',
          core: '#FFFFFF',
          reticle: '#00F0FF',
        };
    }
  }, [settings.trailStyle]);

  // Keep canvas resolution synced to container
  const updateCanvasDimensions = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const rect = container.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    canvas.style.width = `${rect.width}px`;
    canvas.style.height = `${rect.height}px`;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.scale(dpr, dpr);
    }
  }, []);

  useEffect(() => {
    updateCanvasDimensions();
    window.addEventListener('resize', updateCanvasDimensions);
    return () => window.removeEventListener('resize', updateCanvasDimensions);
  }, [updateCanvasDimensions]);

  // Render loop
  const drawScene = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = container.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    // Clear background
    ctx.clearRect(0, 0, width, height);

    // Subtle tactical grid
    if (settings.showGridLines) {
      const step = 40;
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.05)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = 0; x < width; x += step) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
      }
      for (let y = 0; y < height; y += step) {
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
      }
      ctx.stroke();

      // Center crosshair
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.15)';
      ctx.beginPath();
      ctx.moveTo(width / 2 - 20, height / 2);
      ctx.lineTo(width / 2 + 20, height / 2);
      ctx.moveTo(width / 2, height / 2 - 20);
      ctx.lineTo(width / 2, height / 2 + 20);
      ctx.stroke();
    }

    const colors = getTrailColors();

    // 1. Draw completed strokes
    const allStrokes = [...activeStrokes];
    if (currentStrokePointsRef.current.length > 0) {
      allStrokes.push({
        id: 'current-live-stroke',
        points: currentStrokePointsRef.current,
        startTime: currentStrokePointsRef.current[0].timestamp,
        endTime: currentStrokePointsRef.current[currentStrokePointsRef.current.length - 1].timestamp,
        lengthPx: 0,
      });
    }

    for (const stroke of allStrokes) {
      const points = stroke.points;
      if (points.length < 2) continue;

      // Draw outer ambient glow path
      ctx.save();
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      // Pass 1: Wide neon ambient glow
      ctx.shadowColor = colors.reticle;
      ctx.shadowBlur = 18;
      ctx.strokeStyle = colors.glow;
      ctx.lineWidth = 14;
      ctx.beginPath();
      ctx.moveTo(points[0].nx * width, points[0].ny * height);
      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].nx * width, points[i].ny * height);
      }
      ctx.stroke();

      // Pass 2: Electric body stroke
      ctx.shadowBlur = 8;
      ctx.strokeStyle = colors.stroke;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(points[0].nx * width, points[0].ny * height);
      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].nx * width, points[i].ny * height);
      }
      ctx.stroke();

      // Pass 3: Ultra crisp white core
      ctx.shadowBlur = 0;
      ctx.strokeStyle = colors.core;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(points[0].nx * width, points[0].ny * height);
      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].nx * width, points[i].ny * height);
      }
      ctx.stroke();

      // Start waypoint node
      const pStart = points[0];
      ctx.fillStyle = colors.reticle;
      ctx.beginPath();
      ctx.arc(pStart.nx * width, pStart.ny * height, 6, 0, Math.PI * 2);
      ctx.fill();

      // End waypoint node
      const pEnd = points[points.length - 1];
      ctx.fillStyle = '#FF007F';
      ctx.beginPath();
      ctx.arc(pEnd.nx * width, pEnd.ny * height, 5, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    }

    // 2. Draw Replay Ghost Touch Pointer (if replaying)
    if (ghostPointerRef.current && settings.showGhostPointer) {
      const { x, y, pressure, active } = ghostPointerRef.current;
      ctx.save();

      // Glowing outer touch target circle
      ctx.shadowColor = colors.reticle;
      ctx.shadowBlur = 20;

      // Concentric target reticle
      ctx.strokeStyle = colors.reticle;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, y, 22 * (pressure || 1), 0, Math.PI * 2);
      ctx.stroke();

      // Semi-transparent pulse fill
      ctx.fillStyle = active ? colors.glow : 'rgba(0, 240, 255, 0.15)';
      ctx.beginPath();
      ctx.arc(x, y, 16 * (pressure || 1), 0, Math.PI * 2);
      ctx.fill();

      // Inner tactile pip
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fill();

      // Reticle tick crosshairs
      ctx.strokeStyle = colors.reticle;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x - 30, y);
      ctx.lineTo(x - 16, y);
      ctx.moveTo(x + 16, y);
      ctx.lineTo(x + 30, y);
      ctx.moveTo(x, y - 30);
      ctx.lineTo(x, y - 16);
      ctx.moveTo(x, y + 16);
      ctx.lineTo(x, y + 30);
      ctx.stroke();

      ctx.restore();
    }

    // FPS calculation
    frameCountRef.current++;
    const now = performance.now();
    if (now - lastFpsCheckRef.current >= 1000) {
      currentFpsRef.current = frameCountRef.current;
      frameCountRef.current = 0;
      lastFpsCheckRef.current = now;
    }
  }, [activeStrokes, getTrailColors, settings.showGhostPointer, settings.showGridLines]);

  // Main animation / render frame
  useEffect(() => {
    let animId: number;
    const loop = () => {
      drawScene();
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [drawScene]);

  // Pointer event handlers for gesture recording
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Capture pointer
    canvas.setPointerCapture(e.pointerId);
    isPointerDownRef.current = true;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const nx = Math.max(0, Math.min(1, x / rect.width));
    const ny = Math.max(0, Math.min(1, y / rect.height));

    if (playbackState === 'recording') {
      const now = performance.now();
      if (recordingStartTimestampRef.current === 0) {
        recordingStartTimestampRef.current = now;
      }
      const relTime = Math.round(now - recordingStartTimestampRef.current);
      lastPointTimeRef.current = now;

      const point: TouchPoint = {
        x,
        y,
        nx,
        ny,
        timestamp: relTime,
        type: 'down',
        pressure: e.pressure || 0.8,
        velocity: 0,
      };

      currentStrokePointsRef.current = [point];

      if (settings.hapticsEnabled) {
        haptics.trigger('pointTouch');
      }

      onTelemetryUpdate({
        currentX: Math.round(x),
        currentY: Math.round(y),
        currentNx: Number(nx.toFixed(3)),
        currentNy: Number(ny.toFixed(3)),
        velocity: 0,
        fps: currentFpsRef.current,
        samplingRate: 90,
        activeStrokesCount: activeStrokes.length + 1,
        elapsedMs: relTime,
      });
    } else {
      // Just telemetry preview when not recording
      onTelemetryUpdate({
        currentX: Math.round(x),
        currentY: Math.round(y),
        currentNx: Number(nx.toFixed(3)),
        currentNy: Number(ny.toFixed(3)),
        velocity: 0,
        fps: currentFpsRef.current,
        samplingRate: 90,
        activeStrokesCount: activeStrokes.length,
        elapsedMs: 0,
      });
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const nx = Math.max(0, Math.min(1, x / rect.width));
    const ny = Math.max(0, Math.min(1, y / rect.height));

    if (playbackState === 'recording' && isPointerDownRef.current) {
      const now = performance.now();
      const relTime = Math.round(now - recordingStartTimestampRef.current);
      const dt = (now - lastPointTimeRef.current) / 1000;
      lastPointTimeRef.current = now;

      const lastPt = currentStrokePointsRef.current[currentStrokePointsRef.current.length - 1];
      let velocity = 0;
      if (lastPt && dt > 0) {
        const dx = x - lastPt.x;
        const dy = y - lastPt.y;
        velocity = Math.round(Math.hypot(dx, dy) / dt);
      }

      const point: TouchPoint = {
        x,
        y,
        nx,
        ny,
        timestamp: relTime,
        type: 'move',
        pressure: e.pressure || 0.75,
        velocity,
      };

      currentStrokePointsRef.current.push(point);

      onTelemetryUpdate({
        currentX: Math.round(x),
        currentY: Math.round(y),
        currentNx: Number(nx.toFixed(3)),
        currentNy: Number(ny.toFixed(3)),
        velocity,
        fps: currentFpsRef.current,
        samplingRate: 90,
        activeStrokesCount: activeStrokes.length + 1,
        elapsedMs: relTime,
      });
    } else {
      onTelemetryUpdate({
        currentX: Math.round(x),
        currentY: Math.round(y),
        currentNx: Number(nx.toFixed(3)),
        currentNy: Number(ny.toFixed(3)),
        velocity: 0,
        fps: currentFpsRef.current,
        samplingRate: 90,
        activeStrokesCount: activeStrokes.length,
        elapsedMs: 0,
      });
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    isPointerDownRef.current = false;
    const canvas = canvasRef.current;
    if (!canvas) return;

    try {
      canvas.releasePointerCapture(e.pointerId);
    } catch {
      // Ignore
    }

    if (playbackState === 'recording' && currentStrokePointsRef.current.length > 0) {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const nx = Math.max(0, Math.min(1, x / rect.width));
      const ny = Math.max(0, Math.min(1, y / rect.height));
      const now = performance.now();
      const relTime = Math.round(now - recordingStartTimestampRef.current);

      const endPoint: TouchPoint = {
        x,
        y,
        nx,
        ny,
        timestamp: relTime,
        type: 'up',
        pressure: 0,
        velocity: 0,
      };
      currentStrokePointsRef.current.push(endPoint);

      // Compute stroke distance
      let totalLength = 0;
      for (let i = 0; i < currentStrokePointsRef.current.length - 1; i++) {
        const p1 = currentStrokePointsRef.current[i];
        const p2 = currentStrokePointsRef.current[i + 1];
        totalLength += Math.hypot(p2.x - p1.x, p2.y - p1.y);
      }

      const completedStroke: GestureStroke = {
        id: `stroke-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        points: [...currentStrokePointsRef.current],
        startTime: currentStrokePointsRef.current[0].timestamp,
        endTime: relTime,
        lengthPx: Math.round(totalLength),
      };

      onStrokesChange([...activeStrokes, completedStroke]);
      currentStrokePointsRef.current = [];
    }
  };

  // Replay Execution Engine
  useEffect(() => {
    if (playbackState !== 'playing') {
      if (replayAnimIdRef.current) {
        cancelAnimationFrame(replayAnimIdRef.current);
        replayAnimIdRef.current = null;
      }
      ghostPointerRef.current = null;
      return;
    }

    if (activeStrokes.length === 0) {
      onReplayComplete();
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;

    // Collect all points in chronological order
    const allPoints: TouchPoint[] = [];
    for (const stroke of activeStrokes) {
      allPoints.push(...stroke.points);
    }
    allPoints.sort((a, b) => a.timestamp - b.timestamp);

    if (allPoints.length === 0) {
      onReplayComplete();
      return;
    }

    const totalDuration = allPoints[allPoints.length - 1].timestamp;
    const speed = Math.max(0.25, Math.min(5.0, settings.replaySpeed));
    replayStartTimeRef.current = performance.now();
    replayLoopCountRef.current = 1;

    const playLoop = () => {
      const container = containerRef.current;
      if (!container) return;
      const rect = container.getBoundingClientRect();
      const now = performance.now();
      const elapsed = (now - replayStartTimeRef.current) * speed;

      if (elapsed > totalDuration) {
        // Loop completion check
        const maxLoops = settings.repeatCount <= 0 ? Infinity : settings.repeatCount;
        if (replayLoopCountRef.current < maxLoops) {
          replayLoopCountRef.current++;
          replayStartTimeRef.current = performance.now() + (settings.repeatDelayMs || 0) / speed;
          replayAnimIdRef.current = requestAnimationFrame(playLoop);
          return;
        } else {
          // Finished all loops
          ghostPointerRef.current = null;
          onReplayComplete();
          return;
        }
      }

      // Find current position along the trajectory using precise interpolation
      let prevPt = allPoints[0];
      let nextPt = allPoints[allPoints.length - 1];

      for (let i = 0; i < allPoints.length - 1; i++) {
        if (allPoints[i].timestamp <= elapsed && allPoints[i + 1].timestamp >= elapsed) {
          prevPt = allPoints[i];
          nextPt = allPoints[i + 1];
          break;
        }
      }

      const segmentSpan = nextPt.timestamp - prevPt.timestamp;
      const t = segmentSpan > 0 ? (elapsed - prevPt.timestamp) / segmentSpan : 0;

      // Linear interpolation between points
      const curNx = prevPt.nx + (nextPt.nx - prevPt.nx) * t;
      const curNy = prevPt.ny + (nextPt.ny - prevPt.ny) * t;
      const curX = curNx * rect.width;
      const curY = curNy * rect.height;
      const curPressure = (prevPt.pressure || 0.8) + ((nextPt.pressure || 0.8) - (prevPt.pressure || 0.8)) * t;

      ghostPointerRef.current = {
        x: curX,
        y: curY,
        pressure: curPressure,
        active: prevPt.type !== 'up',
      };

      onTelemetryUpdate({
        currentX: Math.round(curX),
        currentY: Math.round(curY),
        currentNx: Number(curNx.toFixed(3)),
        currentNy: Number(curNy.toFixed(3)),
        velocity: Math.round(prevPt.velocity || 0),
        fps: currentFpsRef.current,
        samplingRate: 90,
        activeStrokesCount: activeStrokes.length,
        elapsedMs: Math.round(elapsed),
      });

      replayAnimIdRef.current = requestAnimationFrame(playLoop);
    };

    replayAnimIdRef.current = requestAnimationFrame(playLoop);

    return () => {
      if (replayAnimIdRef.current) {
        cancelAnimationFrame(replayAnimIdRef.current);
      }
    };
  }, [playbackState, activeStrokes, settings.replaySpeed, settings.repeatCount, settings.repeatDelayMs, onReplayComplete, onTelemetryUpdate]);

  // Reset recording reference when recording state changes
  useEffect(() => {
    if (playbackState === 'recording') {
      recordingStartTimestampRef.current = 0;
      currentStrokePointsRef.current = [];
    }
  }, [playbackState]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-hidden select-none touch-none bg-[#090611] rounded-2xl border border-cyan-500/20 shadow-[inset_0_0_40px_rgba(0,240,255,0.03)]"
    >
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className="w-full h-full cursor-crosshair block"
      />

      {/* Target practice reticle overlay info */}
      <div className="absolute top-3 left-3 pointer-events-none flex items-center gap-2">
        <div className={`px-2.5 py-1 rounded text-[11px] font-mono-numbers uppercase tracking-wider font-semibold border ${
          playbackState === 'recording'
            ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 animate-pulse'
            : playbackState === 'playing'
            ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
            : 'bg-purple-950/40 text-purple-300 border-purple-800/40'
        }`}>
          {playbackState === 'recording' && '● REC LIVE'}
          {playbackState === 'playing' && '▶ REPLAY ACTIVE'}
          {playbackState === 'idle' && 'ARENA READY'}
          {playbackState === 'paused' && '⏸ PAUSED'}
        </div>

        {activeStrokes.length > 0 && (
          <div className="px-2 py-1 rounded bg-[#130D26]/80 border border-slate-800 text-[11px] font-mono-numbers text-slate-400">
            {activeStrokes.length} {activeStrokes.length === 1 ? 'stroke' : 'strokes'} · {activeStrokes.reduce((acc, s) => acc + s.points.length, 0)} pts
          </div>
        )}
      </div>

      {/* Guidance overlay when empty */}
      {activeStrokes.length === 0 && playbackState === 'idle' && (
        <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-cyan-500/5 border border-cyan-500/20 flex items-center justify-center mb-3">
            <svg className="w-8 h-8 text-cyan-400/70" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.042 21.672L13.684 16.6m0 0l-2.51 2.225.569-9.47 5.227 7.917-3.286-.672zM12 2.25V4.5m5.834 1.416l-1.591 1.591M21.75 12h-2.25m-1.416 5.834l-1.591-1.591M4.5 12H2.25m3.666-5.834L4.325 4.575m1.591 13.009l-1.591 1.591" />
            </svg>
          </div>
          <p className="text-sm font-semibold text-slate-200">Interactive Gesture Practice Arena</p>
          <p className="text-xs text-slate-400 max-w-xs mt-1">
            Tap <strong className="text-rose-400">Record</strong> to capture swipe trajectories with touch sampling, or choose a preset from <strong className="text-cyan-400">Saved Gestures</strong>.
          </p>
        </div>
      )}
    </div>
  );
};
