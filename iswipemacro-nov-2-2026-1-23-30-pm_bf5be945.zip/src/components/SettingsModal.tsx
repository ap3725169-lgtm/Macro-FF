/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppSettings } from '../types/gesture';
import { haptics } from '../utils/haptics';
import { sound } from '../utils/sound';
import {
  Settings,
  Vibrate,
  Volume2,
  Gauge,
  Repeat,
  Palette,
  Crosshair,
  Smartphone,
  Trash2,
  X,
  Check,
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onClearAllProfiles: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onClearAllProfiles,
}) => {
  const [confirmClear, setConfirmClear] = useState(false);

  if (!isOpen) return null;

  const speedOptions = [0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 5.0];
  const repeatOptions = [1, 2, 3, 5, 10, -1];
  const delayOptions = [0, 150, 300, 500, 1000];

  const handleTestHaptics = (type: 'recordStart' | 'recordStop' | 'replayStart' | 'replayStop') => {
    haptics.trigger(type);
    if (settings.soundEnabled) sound.playClick();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-xl bg-[#0F0A1C] border border-cyan-500/30 rounded-2xl shadow-2xl flex flex-col max-h-[88vh] overflow-hidden text-slate-100">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-purple-900/40 bg-[#140D26]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-wide">Macro Studio Settings</h2>
              <p className="text-xs text-slate-400">Configure replay timing, haptics, and display HUD</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-lg hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Section 1: Haptic & Tactile Feedback */}
          <div className="p-4 rounded-xl bg-[#140D26] border border-purple-900/40 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Vibrate className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="text-sm font-bold text-white">Subtle Haptic Feedback</h3>
                  <p className="text-xs text-slate-400">
                    Provides subtle vibration cues on record start/stop and replay begin/stop
                  </p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.hapticsEnabled}
                  onChange={(e) => {
                    const enabled = e.target.checked;
                    onUpdateSettings({ hapticsEnabled: enabled });
                    haptics.setEnabled(enabled);
                    if (enabled) haptics.trigger('recordStart');
                  }}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
              </label>
            </div>

            {settings.hapticsEnabled && (
              <div className="pt-2 border-t border-purple-900/30 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-300 font-medium">Haptic Intensity</span>
                  <div className="flex items-center gap-1.5 bg-[#090611] p-1 rounded-lg border border-purple-900/50">
                    {(['light', 'medium', 'strong'] as const).map((level) => (
                      <button
                        key={level}
                        onClick={() => {
                          onUpdateSettings({ hapticIntensity: level });
                          haptics.setIntensity(level);
                          haptics.trigger('buttonPress');
                        }}
                        className={`px-3 py-1 rounded text-xs capitalize font-medium transition-all cursor-pointer ${
                          settings.hapticIntensity === level
                            ? 'bg-cyan-500 text-black font-bold shadow-sm'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {level}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Haptic Test Triggers */}
                <div className="space-y-1.5">
                  <span className="text-[11px] text-slate-400">Test Feedback Patterns:</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => handleTestHaptics('recordStart')}
                      className="px-2.5 py-1.5 rounded-lg bg-[#1D1436] hover:bg-[#281B4C] border border-purple-800/40 text-[11px] text-slate-200 text-left transition-colors cursor-pointer"
                    >
                      <span className="text-rose-400 font-bold">● Rec Start</span>: gentle double pulse
                    </button>
                    <button
                      onClick={() => handleTestHaptics('recordStop')}
                      className="px-2.5 py-1.5 rounded-lg bg-[#1D1436] hover:bg-[#281B4C] border border-purple-800/40 text-[11px] text-slate-200 text-left transition-colors cursor-pointer"
                    >
                      <span className="text-rose-400 font-bold">■ Rec Stop</span>: single crisp tick
                    </button>
                    <button
                      onClick={() => handleTestHaptics('replayStart')}
                      className="px-2.5 py-1.5 rounded-lg bg-[#1D1436] hover:bg-[#281B4C] border border-purple-800/40 text-[11px] text-slate-200 text-left transition-colors cursor-pointer"
                    >
                      <span className="text-cyan-400 font-bold">▶ Replay Start</span>: smooth rising pulse
                    </button>
                    <button
                      onClick={() => handleTestHaptics('replayStop')}
                      className="px-2.5 py-1.5 rounded-lg bg-[#1D1436] hover:bg-[#281B4C] border border-purple-800/40 text-[11px] text-slate-200 text-left transition-colors cursor-pointer"
                    >
                      <span className="text-cyan-400 font-bold">❚❚ Replay Stop</span>: double short tick
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Section 2: Replay Speed & Loops */}
          <div className="p-4 rounded-xl bg-[#140D26] border border-purple-900/40 space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm font-bold text-white">Replay Speed Multiplier</span>
                </div>
                <span className="text-sm font-mono-numbers font-bold text-cyan-300">
                  {settings.replaySpeed}x
                </span>
              </div>
              <div className="flex items-center gap-1.5 flex-wrap">
                {speedOptions.map((speed) => (
                  <button
                    key={speed}
                    onClick={() => {
                      onUpdateSettings({ replaySpeed: speed });
                      haptics.trigger('buttonPress');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono-numbers transition-all cursor-pointer ${
                      settings.replaySpeed === speed
                        ? 'bg-cyan-500 text-black font-bold shadow-[0_0_10px_rgba(0,240,255,0.4)]'
                        : 'bg-[#090611] text-slate-300 border border-purple-900/40 hover:border-purple-700'
                    }`}
                  >
                    {speed}x
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-purple-900/30">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Repeat className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm font-bold text-white">Loop Repetitions</span>
                </div>
                <span className="text-sm font-mono-numbers font-bold text-cyan-300">
                  {settings.repeatCount === -1 ? 'Infinite' : `${settings.repeatCount}x`}
                </span>
              </div>
              <div className="flex items-center gap-1.5 flex-wrap">
                {repeatOptions.map((repeat) => (
                  <button
                    key={repeat}
                    onClick={() => {
                      onUpdateSettings({ repeatCount: repeat });
                      haptics.trigger('buttonPress');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono-numbers transition-all cursor-pointer ${
                      settings.repeatCount === repeat
                        ? 'bg-purple-600 text-white font-bold shadow-[0_0_10px_rgba(157,0,255,0.4)]'
                        : 'bg-[#090611] text-slate-300 border border-purple-900/40 hover:border-purple-700'
                    }`}
                  >
                    {repeat === -1 ? '∞ Loop' : `${repeat}x`}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-purple-900/30">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-300 font-medium">Delay Between Loops</span>
                <span className="text-xs font-mono-numbers text-slate-400">{settings.repeatDelayMs}ms</span>
              </div>
              <div className="flex items-center gap-1.5 flex-wrap">
                {delayOptions.map((delay) => (
                  <button
                    key={delay}
                    onClick={() => {
                      onUpdateSettings({ repeatDelayMs: delay });
                      haptics.trigger('buttonPress');
                    }}
                    className={`px-3 py-1 rounded text-xs font-mono-numbers transition-all cursor-pointer ${
                      settings.repeatDelayMs === delay
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/60 font-semibold'
                        : 'bg-[#090611] text-slate-400 border border-purple-900/40'
                    }`}
                  >
                    {delay}ms
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Section 3: Visual & Audio Customization */}
          <div className="p-4 rounded-xl bg-[#140D26] border border-purple-900/40 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <span className="text-sm font-bold text-white">Synthesized Audio Cues</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.soundEnabled}
                  onChange={(e) => {
                    onUpdateSettings({ soundEnabled: e.target.checked });
                    sound.setEnabled(e.target.checked);
                    if (e.target.checked) sound.playClick();
                  }}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
              </label>
            </div>

            <div className="pt-3 border-t border-purple-900/30">
              <div className="flex items-center gap-2 mb-2">
                <Palette className="w-4 h-4 text-cyan-400" />
                <span className="text-sm font-bold text-white">Trail Glow Theme</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'neon-cyan', name: 'Neon Cyan & Electric', color: '#00F0FF' },
                  { id: 'cyber-purple', name: 'Cyber Violet & Pink', color: '#9D00FF' },
                  { id: 'matrix-green', name: 'Matrix Emerald Pulse', color: '#00FF88' },
                  { id: 'solar-gold', name: 'Solar Amber Burst', color: '#FFB800' },
                ].map((trail) => (
                  <button
                    key={trail.id}
                    onClick={() => {
                      onUpdateSettings({ trailStyle: trail.id as AppSettings['trailStyle'] });
                      haptics.trigger('buttonPress');
                    }}
                    className={`p-2.5 rounded-xl border text-left flex items-center gap-2.5 transition-all cursor-pointer ${
                      settings.trailStyle === trail.id
                        ? 'bg-[#1D1436] border-cyan-500/80 shadow-[0_0_12px_rgba(0,240,255,0.2)]'
                        : 'bg-[#090611] border-purple-900/40 hover:border-purple-700/60'
                    }`}
                  >
                    <div className="w-4 h-4 rounded-full shadow-sm" style={{ backgroundColor: trail.color }} />
                    <span className="text-xs font-medium text-slate-200">{trail.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-purple-900/30 space-y-2">
              <span className="text-xs text-slate-300 font-medium">HUD Overlays:</span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <label className="flex items-center gap-2 bg-[#090611] p-2 rounded-lg border border-purple-900/40 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.showGhostPointer}
                    onChange={(e) => onUpdateSettings({ showGhostPointer: e.target.checked })}
                    className="rounded border-purple-800 text-cyan-500 focus:ring-0"
                  />
                  <span>Ghost Touch Reticle</span>
                </label>
                <label className="flex items-center gap-2 bg-[#090611] p-2 rounded-lg border border-purple-900/40 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.showGridLines}
                    onChange={(e) => onUpdateSettings({ showGridLines: e.target.checked })}
                    className="rounded border-purple-800 text-cyan-500 focus:ring-0"
                  />
                  <span>Tactical Grid & Crosshair</span>
                </label>
                <label className="flex items-center gap-2 bg-[#090611] p-2 rounded-lg border border-purple-900/40 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.showCoordinatesHUD}
                    onChange={(e) => onUpdateSettings({ showCoordinatesHUD: e.target.checked })}
                    className="rounded border-purple-800 text-cyan-500 focus:ring-0"
                  />
                  <span>Real-time Coordinates</span>
                </label>
                <label className="flex items-center gap-2 bg-[#090611] p-2 rounded-lg border border-purple-900/40 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.showVelocityVector}
                    onChange={(e) => onUpdateSettings({ showVelocityVector: e.target.checked })}
                    className="rounded border-purple-800 text-cyan-500 focus:ring-0"
                  />
                  <span>Speed & Telemetry</span>
                </label>
              </div>
            </div>
          </div>

          {/* Section 4: Device Display Preset */}
          <div className="p-4 rounded-xl bg-[#140D26] border border-purple-900/40 space-y-3">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-bold text-white">Device Preview Frame</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'redmi-note-11t', label: 'Redmi Note 11T 5G', sub: '20:9 FHD+ 90Hz' },
                { id: 'standard-phone', label: 'Standard Phone', sub: '9:16 Display' },
                { id: 'fullscreen', label: 'Full Arena', sub: 'Responsive' },
              ].map((device) => (
                <button
                  key={device.id}
                  onClick={() => {
                    onUpdateSettings({ deviceFrame: device.id as AppSettings['deviceFrame'] });
                    haptics.trigger('buttonPress');
                  }}
                  className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                    settings.deviceFrame === device.id
                      ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 font-bold'
                      : 'bg-[#090611] border-purple-900/40 text-slate-400 hover:text-white'
                  }`}
                >
                  <p className="text-xs font-semibold">{device.label}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">{device.sub}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Danger Zone: Clear Profiles */}
          <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-500/30 flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold text-rose-300">Clear All Stored Profiles</h4>
              <p className="text-[11px] text-slate-400">Permanently wipes all saved gestures from local storage</p>
            </div>

            {confirmClear ? (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    onClearAllProfiles();
                    setConfirmClear(false);
                    haptics.trigger('warning');
                    sound.playClick();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs cursor-pointer"
                >
                  Confirm Delete
                </button>
                <button
                  onClick={() => setConfirmClear(false)}
                  className="px-2 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setConfirmClear(true)}
                className="px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 border border-rose-600/40 text-xs font-bold text-rose-300 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear All
              </button>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-purple-900/40 bg-[#120B22] flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs transition-colors cursor-pointer"
          >
            Apply & Close
          </button>
        </div>
      </div>
    </div>
  );
};
