/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GestureProfile } from '../types/gesture';
import { PRESET_GESTURES } from '../data/presetGestures';
import { haptics } from '../utils/haptics';
import { sound } from '../utils/sound';
import {
  Folder,
  Play,
  Trash2,
  Edit2,
  Copy,
  Download,
  Upload,
  Check,
  X,
  Sparkles,
  Search,
} from 'lucide-react';

interface SavedGesturesModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedProfiles: GestureProfile[];
  selectedProfile: GestureProfile | null;
  onSelectProfile: (profile: GestureProfile) => void;
  onDeleteProfile: (id: string) => void;
  onRenameProfile: (id: string, newName: string) => void;
  onDuplicateProfile: (profile: GestureProfile) => void;
  onImportProfiles: (profiles: GestureProfile[]) => void;
  onQuickReplay: (profile: GestureProfile) => void;
}

export const SavedGesturesModal: React.FC<SavedGesturesModalProps> = ({
  isOpen,
  onClose,
  savedProfiles,
  selectedProfile,
  onSelectProfile,
  onDeleteProfile,
  onRenameProfile,
  onDuplicateProfile,
  onImportProfiles,
  onQuickReplay,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editNameText, setEditNameText] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredProfiles = savedProfiles.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleStartRename = (profile: GestureProfile) => {
    setEditingId(profile.id);
    setEditNameText(profile.name);
  };

  const handleSaveRename = (id: string) => {
    if (editNameText.trim()) {
      onRenameProfile(id, editNameText.trim());
      haptics.trigger('buttonPress');
      sound.playClick();
    }
    setEditingId(null);
  };

  const handleExportProfileJson = (profile: GestureProfile) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(profile, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${profile.name.replace(/\\s+/g, '_')}_gesture.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    haptics.trigger('buttonPress');
  };

  const handleExportAllJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(savedProfiles, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `iSwipeMacro_All_Profiles_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    haptics.trigger('buttonPress');
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed)) {
          onImportProfiles(parsed);
        } else if (parsed && parsed.strokes) {
          onImportProfiles([parsed]);
        }
        haptics.trigger('buttonPress');
        sound.playClick();
      } catch {
        alert('Invalid gesture JSON format');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-[#0F0A1C] border border-cyan-500/30 rounded-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden text-slate-100">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-purple-900/40 bg-[#140D26]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Folder className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-wide">Gesture Profile Library</h2>
              <p className="text-xs text-slate-400">
                {savedProfiles.length} saved {savedProfiles.length === 1 ? 'profile' : 'profiles'} stored locally
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onImportProfiles(PRESET_GESTURES)}
              className="px-3 py-1.5 rounded-lg bg-purple-900/40 hover:bg-purple-800/60 border border-purple-700/50 text-xs font-medium text-purple-200 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              Load Presets
            </button>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-lg hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search & Actions Bar */}
        <div className="p-4 border-b border-purple-900/30 bg-[#0B0715] flex flex-wrap items-center justify-between gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search gestures by name or category..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-lg bg-[#150F26] border border-purple-900/50 text-xs text-slate-200 focus:outline-none focus:border-cyan-500/60"
            />
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <label className="px-3 py-2 rounded-lg bg-[#1A1230] hover:bg-[#251A45] border border-purple-800/50 text-xs font-medium text-slate-300 transition-colors flex items-center gap-1.5 cursor-pointer">
              <Upload className="w-3.5 h-3.5 text-cyan-400" />
              Import JSON
              <input type="file" accept=".json" onChange={handleImportFile} className="hidden" />
            </label>

            {savedProfiles.length > 0 && (
              <button
                onClick={handleExportAllJson}
                className="px-3 py-2 rounded-lg bg-[#1A1230] hover:bg-[#251A45] border border-purple-800/50 text-xs font-medium text-slate-300 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                Export All
              </button>
            )}
          </div>
        </div>

        {/* Gesture List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {filteredProfiles.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <p className="text-sm">No gestures found matching your search.</p>
              <button
                onClick={() => onImportProfiles(PRESET_GESTURES)}
                className="mt-3 px-4 py-2 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-medium cursor-pointer"
              >
                Restore Default Presets
              </button>
            </div>
          ) : (
            filteredProfiles.map((profile) => {
              const isSelected = selectedProfile?.id === profile.id;
              const isEditing = editingId === profile.id;
              const isConfirmingDelete = confirmDeleteId === profile.id;

              return (
                <div
                  key={profile.id}
                  className={`p-3.5 rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-gradient-to-r from-cyan-950/40 to-purple-950/40 border-cyan-500/60 shadow-[0_0_15px_rgba(0,240,255,0.15)]'
                      : 'bg-[#140D26]/80 hover:bg-[#1A1230] border-purple-900/40 hover:border-purple-700/60'
                  }`}
                >
                  <div className="flex items-center justify-between gap-3">
                    
                    {/* Left: Info */}
                    <div className="flex-1 min-w-0">
                      {isEditing ? (
                        <div className="flex items-center gap-2 mb-1">
                          <input
                            type="text"
                            value={editNameText}
                            onChange={(e) => setEditNameText(e.target.value)}
                            className="px-2 py-1 rounded bg-[#090611] border border-cyan-500/50 text-xs text-white focus:outline-none w-full"
                            autoFocus
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveRename(profile.id);
                              if (e.key === 'Escape') setEditingId(null);
                            }}
                          />
                          <button
                            onClick={() => handleSaveRename(profile.id)}
                            className="p-1 rounded bg-cyan-500 text-black hover:bg-cyan-400 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingId(null)}
                            className="p-1 rounded bg-white/10 text-slate-300 hover:bg-white/20 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-bold text-white truncate">{profile.name}</h3>
                          <span className="text-[10px] font-mono-numbers px-2 py-0.5 rounded bg-purple-900/60 border border-purple-700/40 text-purple-200">
                            {profile.category}
                          </span>
                        </div>
                      )}

                      {/* Metadata Row */}
                      <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono-numbers text-slate-400 mt-1">
                        <span>{profile.durationMs}ms</span>
                        <span>·</span>
                        <span>{profile.totalPoints} points</span>
                        <span>·</span>
                        <span>{Math.round(profile.totalDistancePx)}px path</span>
                        <span>·</span>
                        <span className="text-cyan-400 font-semibold">{Math.round(profile.averageVelocityPxPerSec)} px/s</span>
                      </div>
                    </div>

                    {/* Right: Actions */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      {isConfirmingDelete ? (
                        <div className="flex items-center gap-1 bg-rose-950/80 p-1 rounded-lg border border-rose-500/40">
                          <span className="text-[10px] text-rose-300 px-1 font-semibold">Delete?</span>
                          <button
                            onClick={() => {
                              onDeleteProfile(profile.id);
                              setConfirmDeleteId(null);
                              haptics.trigger('buttonPress');
                              sound.playClick();
                            }}
                            className="px-2 py-0.5 rounded bg-rose-600 hover:bg-rose-500 text-[10px] font-bold text-white cursor-pointer"
                          >
                            Yes
                          </button>
                          <button
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300 cursor-pointer"
                          >
                            No
                          </button>
                        </div>
                      ) : (
                        <>
                          <button
                            onClick={() => {
                              onSelectProfile(profile);
                              onQuickReplay(profile);
                              onClose();
                            }}
                            title="Replay in Practice Arena"
                            className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center gap-1.5 shadow-[0_0_10px_rgba(0,240,255,0.3)] transition-transform active:scale-95 cursor-pointer"
                          >
                            <Play className="w-3.5 h-3.5 fill-current" />
                            Load & Play
                          </button>

                          <button
                            onClick={() => handleStartRename(profile)}
                            title="Rename"
                            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => {
                              onDuplicateProfile(profile);
                              haptics.trigger('buttonPress');
                              sound.playClick();
                            }}
                            title="Duplicate Profile"
                            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => handleExportProfileJson(profile)}
                            title="Export Single JSON"
                            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => setConfirmDeleteId(profile.id)}
                            title="Delete"
                            className="p-1.5 rounded-lg hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-purple-900/40 bg-[#120B22] flex items-center justify-between text-xs text-slate-400">
          <span>Profiles saved locally via browser storage</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
