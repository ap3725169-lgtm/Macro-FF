/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { getAndroidProjectFiles, generateAndroidProjectZip, downloadZipBlob, AndroidProjectFile } from '../utils/androidProjectExport';
import { haptics } from '../utils/haptics';
import { sound } from '../utils/sound';
import {
  Download,
  FileCode,
  FolderTree,
  Copy,
  Check,
  Terminal,
  Smartphone,
  ShieldCheck,
  X,
  Code2,
} from 'lucide-react';

interface AndroidProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidProjectModal: React.FC<AndroidProjectModalProps> = ({ isOpen, onClose }) => {
  const files = getAndroidProjectFiles();
  const [selectedFilePath, setSelectedFilePath] = useState<string>('app/src/main/java/com/iswipemacro/app/MainActivity.kt');
  const [copied, setCopied] = useState<boolean>(false);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'code' | 'instructions' | 'tree'>('code');

  if (!isOpen) return null;

  const currentFile = files.find((f) => f.path === selectedFilePath) || files[0];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    haptics.trigger('buttonPress');
    sound.playClick();
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsExporting(true);
    haptics.trigger('buttonPress');
    sound.playClick();
    try {
      const blob = await generateAndroidProjectZip();
      downloadZipBlob(blob, 'iSwipeMacro_Android_Studio_Project.zip');
    } catch (e) {
      console.error('Failed to generate ZIP:', e);
      alert('Error creating ZIP export. You can still copy the source files directly.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-5xl bg-[#0C0817] border border-cyan-500/40 rounded-2xl shadow-2xl flex flex-col h-[90vh] overflow-hidden text-slate-100">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-purple-900/40 bg-[#140D26]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-wide">Android Studio Source Code & APK Export</h2>
                <span className="text-[10px] font-mono-numbers px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  Ready to Build
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Kotlin 2.0+ · Jetpack Compose · Haptic Feedback Engine · Redmi Note 11T 5G Compatible
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleDownloadZip}
              disabled={isExporting}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs flex items-center gap-2 shadow-[0_0_15px_rgba(0,240,255,0.3)] transition-transform active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              {isExporting ? 'Generating ZIP...' : 'Download Project (.ZIP)'}
            </button>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-lg hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Strip */}
        <div className="flex items-center justify-between px-6 py-2.5 bg-[#090611] border-b border-purple-900/30">
          <div className="flex items-center gap-1.5 p-1 bg-[#140D26] rounded-lg border border-purple-900/40">
            <button
              onClick={() => setActiveTab('code')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'code' ? 'bg-cyan-500 text-black shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              Source Code Inspector ({files.length} files)
            </button>

            <button
              onClick={() => setActiveTab('instructions')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'instructions' ? 'bg-cyan-500 text-black shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              APK Build Guide
            </button>

            <button
              onClick={() => setActiveTab('tree')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'tree' ? 'bg-cyan-500 text-black shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <FolderTree className="w-3.5 h-3.5" />
              Project Structure
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400 font-mono-numbers">
            <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
            <span>Target: Redmi Note 11T 5G (Android 11–14)</span>
          </div>
        </div>

        {/* Tab 1: Source Code View */}
        {activeTab === 'code' && (
          <div className="flex-1 flex overflow-hidden">
            {/* File Sidebar */}
            <div className="w-72 border-r border-purple-900/40 bg-[#0B0715] overflow-y-auto p-3 space-y-1">
              <div className="px-2 py-1 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Android Project Files
              </div>
              {files.map((file) => {
                const isSelected = file.path === selectedFilePath;
                return (
                  <button
                    key={file.path}
                    onClick={() => {
                      setSelectedFilePath(file.path);
                      haptics.trigger('buttonPress');
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-mono transition-all flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 font-bold'
                        : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
                    }`}
                  >
                    <span className="truncate">{file.path.split('/').pop()}</span>
                    <span className="text-[10px] text-slate-600 uppercase shrink-0 ml-1">
                      {file.language}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Code Content */}
            <div className="flex-1 flex flex-col overflow-hidden bg-[#07050E]">
              {/* File Info Bar */}
              <div className="flex items-center justify-between px-4 py-2.5 border-b border-purple-900/30 bg-[#100A1F]">
                <div>
                  <span className="text-xs font-mono text-cyan-400 font-bold">{currentFile.path}</span>
                  <p className="text-[11px] text-slate-400">{currentFile.description}</p>
                </div>
                <button
                  onClick={handleCopyCode}
                  className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium text-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Copied!' : 'Copy Code'}
                </button>
              </div>

              {/* Code Pre Block */}
              <div className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-300 leading-relaxed">
                <pre className="select-text whitespace-pre">
                  <code>{currentFile.content}</code>
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Build Instructions */}
        {activeTab === 'instructions' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#07050E]">
            <div className="p-4 rounded-xl bg-[#140D26] border border-cyan-500/30">
              <h3 className="text-base font-bold text-white mb-2 flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-cyan-400" />
                Step-by-Step: How to Build & Install on Redmi Note 11T 5G
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                The Redmi Note 11T 5G features a 6.6-inch FHD+ IPS LCD display with a 90Hz AdaptiveSync refresh rate and 240Hz touch sampling rate. The iSwipeMacro project is compiled with hardware acceleration enabled and standard non-root sandbox execution.
              </p>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#100A1F] border border-purple-900/40">
                <div className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-2">
                  1. Enable USB Debugging on Redmi Note 11T 5G
                </div>
                <ol className="list-decimal list-inside text-xs text-slate-300 space-y-1.5">
                  <li>Open <strong>Settings &gt; About phone</strong>.</li>
                  <li>Tap <strong>MIUI version</strong> 7 times until you see "You are now a developer!".</li>
                  <li>Go back to <strong>Settings &gt; Additional settings &gt; Developer options</strong>.</li>
                  <li>Turn ON <strong>USB Debugging</strong> and <strong>Install via USB</strong>.</li>
                  <li>Connect phone to PC with USB cable and choose "Transfer files / Android Auto".</li>
                </ol>
              </div>

              <div className="p-4 rounded-xl bg-[#100A1F] border border-purple-900/40">
                <div className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-2">
                  2. Open in Android Studio & Sync Gradle
                </div>
                <p className="text-xs text-slate-300 mb-2">
                  Extract the downloaded <code>iSwipeMacro_Android_Studio_Project.zip</code>, then in Android Studio select <strong>File &gt; Open</strong> and choose the folder.
                </p>
                <div className="p-2.5 rounded-lg bg-[#05030A] border border-purple-900/50 font-mono text-xs text-cyan-300">
                  Gradle 8.9 · Android Gradle Plugin 8.7.2 · Kotlin 2.0.21 · Jetpack Compose 2024.11.00
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#100A1F] border border-purple-900/40">
                <div className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-2">
                  3. Build Debug APK via Command Line
                </div>
                <p className="text-xs text-slate-300 mb-2">
                  Run the following command inside the project directory:
                </p>
                <div className="p-3 rounded-lg bg-[#05030A] border border-purple-900/50 font-mono text-xs text-slate-200 flex items-center justify-between">
                  <code>./gradlew assembleDebug</code>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText('./gradlew assembleDebug');
                      haptics.trigger('buttonPress');
                    }}
                    className="text-xs text-cyan-400 hover:underline cursor-pointer"
                  >
                    Copy
                  </button>
                </div>
                <p className="text-[11px] text-slate-400 mt-2">
                  The compiled APK will be at: <code className="text-cyan-300">app/build/outputs/apk/debug/app-debug.apk</code>
                </p>
              </div>

              <div className="p-4 rounded-xl bg-purple-950/20 border border-purple-800/40 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white">Non-Root & Security Compliance Notice</h4>
                  <p className="text-xs text-slate-300 mt-0.5">
                    iSwipeMacro operates strictly within its own application practice canvas. It does not request Accessibility Service touch injection, does not modify system files, and does not require root privileges. All profiles are stored in private local app storage.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Project Tree View */}
        {activeTab === 'tree' && (
          <div className="flex-1 overflow-y-auto p-6 bg-[#07050E]">
            <div className="p-4 rounded-xl bg-[#140D26] border border-purple-900/40 font-mono text-xs text-slate-300 leading-relaxed">
              <pre className="whitespace-pre">
{`iSwipeMacro/
├── settings.gradle.kts                   # Project repositories and module includes
├── build.gradle.kts                      # Root Gradle build script
├── gradlew                               # Unix/macOS Gradle wrapper executable
├── gradlew.bat                           # Windows Gradle wrapper batch script
├── README.md                             # Step-by-step setup and APK build guide
├── gradle/
│   ├── libs.versions.toml                # Android Version Catalog (Compose, Coroutines, etc.)
│   └── wrapper/
│       └── gradle-wrapper.properties     # Gradle 8.9 distribution wrapper
└── app/
    ├── build.gradle.kts                  # App module with Compose & Android 15 SDK
    ├── proguard-rules.pro                # R8 & Proguard retention rules
    └── src/
        └── main/
            ├── AndroidManifest.xml       # Hardware acceleration & VIBRATE permission
            ├── java/
            │   └── com/iswipemacro/app/
            │       ├── MainActivity.kt            # App entry point
            │       ├── model/
            │       │   └── GestureModels.kt       # TouchPoint, GestureStroke, GestureProfile
            │       ├── util/
            │       │   └── HapticsManager.kt      # Subtle tactile vibration patterns
            │       ├── viewmodel/
            │       │   └── GestureViewModel.kt    # State & recording/replay coroutine loop
            │       └── ui/
            │           ├── HomeScreen.kt          # Modern gaming UI dashboard
            │           ├── PracticeCanvas.kt      # Glowing neon canvas & ghost touch replayer
            │           ├── SavedGesturesSheet.kt  # Bottom sheet library manager
            │           ├── SettingsDialog.kt      # Settings & speed multiplier
            │           ├── SaveGestureDialog.kt   # Profile naming & category dialog
            │           ├── AppInfoDialog.kt       # Redmi Note 11T 5G specs & safety policy
            │           └── theme/
            │               ├── Color.kt           # Dark purple, obsidian, cyber cyan palette
            │               ├── Type.kt            # Typography setup
            │               └── Theme.kt           # Material3 dark theme setup
            └── res/
                ├── mipmap-xxxhdpi/       # Official iSwipeMacro app icons (48px - 192px)
                ├── values/
                │   ├── strings.xml                # Localized strings
                │   ├── colors.xml                 # Android color resources
                │   └── themes.xml                 # Material theme styles
                └── xml/
                    ├── data_extraction_rules.xml  # Android 12+ backup
                    └── backup_rules.xml           # SharedPreferences persistence`}
              </pre>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-6 py-3 border-t border-purple-900/40 bg-[#120B22] flex items-center justify-between text-xs text-slate-400">
          <span>All {files.length} Android Studio files bundled and validated</span>
          <button
            onClick={handleDownloadZip}
            disabled={isExporting}
            className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            {isExporting ? 'Preparing ZIP...' : 'Export Android Studio ZIP'}
          </button>
        </div>
      </div>
    </div>
  );
};
