import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeCoordinate,
  denormalizeCoordinate,
  calculateDistance,
  calculateStrokeLength,
  calculateAverageVelocity,
  interpolateReplayPosition,
  createGestureProfile,
} from './gestureMath';
import { TouchPoint, GestureStroke } from '../types/gesture';

test('normalizeCoordinate maps value within [0, 1] range', () => {
  assert.equal(normalizeCoordinate(540, 1080), 0.5);
  assert.equal(normalizeCoordinate(0, 1080), 0);
  assert.equal(normalizeCoordinate(1080, 1080), 1);
  assert.equal(normalizeCoordinate(-50, 1080), 0);
  assert.equal(normalizeCoordinate(1200, 1080), 1);
});

test('denormalizeCoordinate converts relative to absolute pixels', () => {
  assert.equal(denormalizeCoordinate(0.5, 1080), 540);
  assert.equal(denormalizeCoordinate(0.25, 2400), 600);
});

test('calculateDistance computes 2D Euclidean distance', () => {
  assert.equal(calculateDistance(0, 0, 3, 4), 5);
  assert.equal(calculateDistance(100, 100, 100, 200), 100);
});

test('calculateStrokeLength computes cumulative trajectory path length', () => {
  const points: TouchPoint[] = [
    { x: 0, y: 0, nx: 0, ny: 0, timestamp: 0, type: 'down' },
    { x: 100, y: 0, nx: 0.1, ny: 0, timestamp: 50, type: 'move' },
    { x: 100, y: 100, nx: 0.1, ny: 0.1, timestamp: 100, type: 'up' },
  ];
  assert.equal(calculateStrokeLength(points), 200);
});

test('calculateAverageVelocity computes pixels per second', () => {
  assert.equal(calculateAverageVelocity(500, 1000), 500);
  assert.equal(calculateAverageVelocity(300, 200), 1500);
  assert.equal(calculateAverageVelocity(100, 0), 0);
});

test('interpolateReplayPosition computes smooth coordinates along trajectory', () => {
  const points: TouchPoint[] = [
    { x: 0, y: 0, nx: 0.2, ny: 0.4, timestamp: 0, type: 'down', pressure: 0.8 },
    { x: 100, y: 200, nx: 0.6, ny: 0.8, timestamp: 100, type: 'up', pressure: 0.6 },
  ];

  const mid = interpolateReplayPosition(points, 50, 1000, 2000);
  assert.equal(mid.nx, 0.4);
  assert.equal(mid.ny, 0.6);
  assert.equal(mid.x, 400);
  assert.equal(mid.y, 1200);
  assert.equal(mid.pressure, 0.7);
  assert.equal(mid.isDown, true);
});

test('createGestureProfile creates a populated profile with telemetry', () => {
  const strokes: GestureStroke[] = [
    {
      id: 's1',
      points: [
        { x: 0, y: 0, nx: 0, ny: 0, timestamp: 0, type: 'down' },
        { x: 300, y: 400, nx: 0.3, ny: 0.4, timestamp: 250, type: 'up' },
      ],
      startTime: 0,
      endTime: 250,
      lengthPx: 500,
    },
  ];

  const profile = createGestureProfile('Flick Test', 'FPS', strokes);
  assert.equal(profile.name, 'Flick Test');
  assert.equal(profile.category, 'FPS');
  assert.equal(profile.totalPoints, 2);
  assert.equal(profile.totalDistancePx, 500);
  assert.equal(profile.durationMs, 250);
  assert.equal(profile.averageVelocityPxPerSec, 2000);
});
