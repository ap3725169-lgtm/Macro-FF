/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TouchPoint, GestureStroke, GestureProfile } from '../types/gesture';

/**
 * Normalizes touch coordinates to 0.0 - 1.0 relative space.
 */
export function normalizeCoordinate(val: number, max: number): number {
  if (max <= 0) return 0;
  return Math.max(0, Math.min(1, Number((val / max).toFixed(4))));
}

/**
 * Scales normalized coordinate back to absolute pixels.
 */
export function denormalizeCoordinate(normVal: number, max: number): number {
  return normVal * max;
}

/**
 * Calculates Euclidean distance between two points.
 */
export function calculateDistance(x1: number, y1: number, x2: number, y2: number): number {
  return Math.hypot(x2 - x1, y2 - y1);
}

/**
 * Calculates total path length in pixels for a sequence of points.
 */
export function calculateStrokeLength(points: TouchPoint[]): number {
  if (points.length < 2) return 0;
  let total = 0;
  for (let i = 0; i < points.length - 1; i++) {
    total += calculateDistance(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y);
  }
  return Math.round(total);
}

/**
 * Calculates average velocity in pixels per second.
 */
export function calculateAverageVelocity(distancePx: number, durationMs: number): number {
  if (durationMs <= 0) return 0;
  return Math.round(distancePx / (durationMs / 1000));
}

/**
 * Interpolates ghost pointer position along a trajectory at given elapsed time.
 */
export function interpolateReplayPosition(
  allPoints: TouchPoint[],
  elapsedMs: number,
  canvasWidth: number,
  canvasHeight: number
): { x: number; y: number; nx: number; ny: number; pressure: number; isDown: boolean } {
  if (allPoints.length === 0) {
    return { x: 0, y: 0, nx: 0, ny: 0, pressure: 0, isDown: false };
  }
  if (allPoints.length === 1 || elapsedMs <= allPoints[0].timestamp) {
    const p = allPoints[0];
    return {
      x: p.nx * canvasWidth,
      y: p.ny * canvasHeight,
      nx: p.nx,
      ny: p.ny,
      pressure: p.pressure ?? 0.8,
      isDown: p.type !== 'up',
    };
  }

  const lastPt = allPoints[allPoints.length - 1];
  if (elapsedMs >= lastPt.timestamp) {
    return {
      x: lastPt.nx * canvasWidth,
      y: lastPt.ny * canvasHeight,
      nx: lastPt.nx,
      ny: lastPt.ny,
      pressure: lastPt.pressure ?? 0,
      isDown: false,
    };
  }

  // Find bounding segment
  let p1 = allPoints[0];
  let p2 = allPoints[1];
  for (let i = 0; i < allPoints.length - 1; i++) {
    if (allPoints[i].timestamp <= elapsedMs && allPoints[i + 1].timestamp >= elapsedMs) {
      p1 = allPoints[i];
      p2 = allPoints[i + 1];
      break;
    }
  }

  const span = p2.timestamp - p1.timestamp;
  const t = span > 0 ? (elapsedMs - p1.timestamp) / span : 0;

  const nx = p1.nx + (p2.nx - p1.nx) * t;
  const ny = p1.ny + (p2.ny - p1.ny) * t;
  const press1 = p1.pressure ?? 0.8;
  const press2 = p2.pressure ?? 0.8;
  const pressure = press1 + (press2 - press1) * t;

  return {
    x: Number((nx * canvasWidth).toFixed(2)),
    y: Number((ny * canvasHeight).toFixed(2)),
    nx: Number(nx.toFixed(4)),
    ny: Number(ny.toFixed(4)),
    pressure: Number(pressure.toFixed(3)),
    isDown: p1.type !== 'up',
  };
}

/**
 * Creates a validated GestureProfile object.
 */
export function createGestureProfile(
  name: string,
  category: GestureProfile['category'],
  strokes: GestureStroke[],
  color: string = '#00F0FF'
): GestureProfile {
  const totalPoints = strokes.reduce((acc, s) => acc + s.points.length, 0);
  const totalDistancePx = strokes.reduce((acc, s) => acc + s.lengthPx, 0);
  const durationMs = strokes.length > 0 ? Math.max(...strokes.map((s) => s.endTime)) : 0;
  const averageVelocityPxPerSec = calculateAverageVelocity(totalDistancePx, durationMs);

  return {
    id: `profile-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    name: name.trim() || 'Untitled Gesture',
    description: `${category} profile with ${strokes.length} stroke(s) and ${totalPoints} points.`,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    durationMs,
    strokes,
    totalPoints,
    totalDistancePx,
    averageVelocityPxPerSec,
    category,
    color,
    deviceSource: 'Redmi Note 11T 5G (FHD+)',
  };
}
